/* Bigshow data store in SQL Server.
   Every record (product, sale, purchase, ...) is one row: (col, id, data JSON).
   All changes of one action are written in ONE transaction, so nothing is half-saved. */
const sql = require('./sqlib');

const SCHEMA = `
IF OBJECT_ID('bs_doc') IS NULL CREATE TABLE bs_doc (col VARCHAR(20) NOT NULL, id BIGINT NOT NULL, data NVARCHAR(MAX) NOT NULL,
  updated DATETIME2 NOT NULL DEFAULT SYSDATETIME(), CONSTRAINT pk_bs_doc PRIMARY KEY (col, id));
IF OBJECT_ID('bs_kv') IS NULL CREATE TABLE bs_kv (k VARCHAR(40) NOT NULL PRIMARY KEY, v NVARCHAR(MAX) NOT NULL);
IF OBJECT_ID('bs_img') IS NULL CREATE TABLE bs_img (id VARCHAR(40) NOT NULL PRIMARY KEY, data VARCHAR(MAX) NOT NULL);`;

let pool;
async function init(p) { pool = p; await pool.request().batch(SCHEMA);
  try { await pool.request().batch("IF DATABASEPROPERTYEX(DB_NAME(),'IsAutoClose')=1 EXEC('ALTER DATABASE ['+DB_NAME()+'] SET AUTO_CLOSE OFF')"); } catch (e) {} }   // Express closes the database when idle; reopening is slow

// NOLOCK: reading never waits behind a save that is still open (that wait made screens hang for a minute)
async function load1() {
  const D = {}, IMG = {}; let t = Date.now();
  for (const r of (await pool.request().query('SELECT col, data FROM bs_doc WITH (NOLOCK) ORDER BY col, id')).recordset)
    (D[r.col] = D[r.col] || []).push(JSON.parse(r.data));
  LOG('  read bs_doc ' + (Date.now() - t) + 'ms'); t = Date.now();
  for (const r of (await pool.request().query('SELECT k, v FROM bs_kv WITH (NOLOCK)')).recordset) D['$' + r.k] = JSON.parse(r.v);
  LOG('  read bs_kv ' + (Date.now() - t) + 'ms'); t = Date.now();
  for (const r of (await pool.request().query('SELECT id, data FROM bs_img WITH (NOLOCK)')).recordset) IMG[r.id] = r.data;
  LOG('  read bs_img ' + (Date.now() - t) + 'ms, ' + Object.keys(IMG).length + ' images');
  return { D, IMG };
}

// a load that hangs (after sleep / broken connection) is given up after 12 s and tried again, up to 4 times
// The data is read from SQL Server once and kept in memory; every save updates memory too.
// A copy is also kept in a file (cache.json), so the screens open at once even when SQL Server is slow or not ready yet;
// SQL Server is then read again in the background and the newest data replaces the copy.
const fs = require('fs');
let CACHE = null, FILE = null, LOG = () => {}, wT = null, bg = null, during = [];
function setup(o) { FILE = o.file; LOG = o.log || LOG;
  try { if (!CACHE && FILE && fs.existsSync(FILE)) { CACHE = JSON.parse(fs.readFileSync(FILE, 'utf8')); LOG('cache file read'); } } catch (e) { LOG('cache file bad: ' + e.message); CACHE = null; } }
function writeFile() { if (!FILE || !CACHE) return; try { fs.writeFileSync(FILE + '.tmp', JSON.stringify(CACHE)); fs.renameSync(FILE + '.tmp', FILE); } catch (e) { LOG('cache write ' + e.message); } }
const writeSoon = () => { clearTimeout(wT); wT = setTimeout(writeFile, 300); };
function apply(ops, into) { if (!into && bg) during.push(...ops); const C = into || CACHE; if (!C) return; const { D, IMG } = C;
  for (const op of ops) {
    if (op.t === 'put') { const a = D[op.c] = D[op.c] || [], i = a.findIndex(x => x.id === op.o.id), o = JSON.parse(JSON.stringify(op.o)); if (i >= 0) a[i] = o; else a.push(o); }
    else if (op.t === 'del') { if (D[op.c]) D[op.c] = D[op.c].filter(x => x.id !== op.id); }
    else if (op.t === 'kv') D['$' + op.k] = JSON.parse(JSON.stringify(op.v));
    else if (op.t === 'img') { if (op.v == null) delete IMG[String(op.id)]; else IMG[String(op.id)] = op.v; } }
  if (!into) writeSoon(); }
const hasCache = () => !!CACHE;
// read SQL Server in the background; the old copy is used until the new one is complete
function refresh() { if (bg) return bg; const t = Date.now(); during = [];
  bg = loadDb().then(r => { apply(during, r); during = []; CACHE = r; writeFile(); LOG('database read ok ' + (Date.now() - t) + 'ms'); return r; })
    .catch(e => { LOG('database read ERR ' + e.message); throw e; }).finally(() => { bg = null; });
  return bg; }
async function load() { if (CACHE) return CACHE; return await refresh(); }
async function loadDb() { let err;
  for (let k = 1; k <= 4; k++) {
    try { return await Promise.race([load1(), new Promise((_, rej) => setTimeout(() => rej(new Error('load timeout')), 30000))]); }
    catch (e) { err = e; await new Promise(r => setTimeout(r, 800 * k)); } }
  throw err; }

/* ops: [{t:'put',c,o}, {t:'del',c,id}, {t:'kv',k,v}, {t:'img',id,v}]  (v null = delete image) */
async function tx1(ops) {
  if (!pool) throw new Error('database not connected');
  const t = new sql.Transaction(pool); await t.begin();
  try {
    for (const op of ops) {
      const r = new sql.Request(t);
      if (op.t === 'put') { r.input('c', op.c).input('id', sql.BigInt, op.o.id).input('d', JSON.stringify(op.o));
        await r.query(`UPDATE bs_doc SET data=@d, updated=SYSDATETIME() WHERE col=@c AND id=@id;
                       IF @@ROWCOUNT=0 INSERT INTO bs_doc(col,id,data) VALUES(@c,@id,@d)`); }
      else if (op.t === 'del') { r.input('c', op.c).input('id', sql.BigInt, op.id); await r.query('DELETE FROM bs_doc WHERE col=@c AND id=@id'); }
      else if (op.t === 'kv') { r.input('k', op.k).input('v', JSON.stringify(op.v));
        await r.query(`UPDATE bs_kv SET v=@v WHERE k=@k; IF @@ROWCOUNT=0 INSERT INTO bs_kv(k,v) VALUES(@k,@v)`); }
      else if (op.t === 'img') { r.input('id', String(op.id));
        if (op.v == null) await r.query('DELETE FROM bs_img WHERE id=@id');
        else { r.input('v', sql.VarChar(sql.MAX), op.v); await r.query(`UPDATE bs_img SET data=@v WHERE id=@id; IF @@ROWCOUNT=0 INSERT INTO bs_img(id,data) VALUES(@id,@v)`); } }
    }
    await t.commit(); return { ok: true, n: ops.length };
  } catch (e) { try { await t.rollback(); } catch (e2) {} throw e; }     // keep the real error, not the rollback error
}
/* a connection can die while the laptop sleeps: try the whole transaction again (it was rolled back, so nothing is doubled) */
async function tx(ops) {
  for (let k = 1; ; k++) {
    try { const r = await tx1(ops); try { apply(ops); } catch (e) { LOG('cache apply ' + e.message); } return r; }
    catch (e) { if (k >= 5) throw e; await new Promise(r => setTimeout(r, 1000 * k)); }
  }
}
module.exports = { setup, init, load, tx, hasCache, refresh, flush: writeFile };
