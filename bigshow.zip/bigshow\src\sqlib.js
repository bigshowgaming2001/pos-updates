let sql;
try { sql = require('mssql'); }
catch (e) { sql = require(require('path').join(process.resourcesPath, '..', '..', 'node_modules', 'mssql')); }
module.exports = sql;
