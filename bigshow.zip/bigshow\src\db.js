/* Database access (SQL Server Express). Uses the same SQL login that PerfumePOS setup created
   (%APPDATA%\\PerfumePOS\\config.json), but its own database: bigshow_pos.
   Only the named queries below can be run from the screens — the screens never send raw SQL. */
const sql = require('./sqlib');

let pool = null;
async function connect(c) {
  if (pool) return pool;
  const conf = {
    server: c.server || 'localhost', database: c.database || 'bigshow_pos', user: c.user, password: c.password,
    options: { encrypt: false, trustServerCertificate: true, enableArithAbort: true },
    pool: { max: 5, min: 2, idleTimeoutMillis: 3600000 }, connectionTimeout: 15000, requestTimeout: 60000   // keep 2 connections open: opening new ones sometimes fails on this PC
  };
  if (c.instance) conf.options.instanceName = c.instance; else conf.port = Number(c.port) || 1433;
  const p = new sql.ConnectionPool(conf); p.on('error', () => {}); pool = await p.connect();
  return pool;
}

async function run(text, params = {}) {
  const req = pool.request();
  for (const [k, v] of Object.entries(params)) req.input(k, v);
  const r = await req.query(text);
  return r.recordset || [];
}

/* period helpers shared by reports, bot and closing */
const PROFIT_SQL = `
  SELECT
    (SELECT COUNT(*) FROM sales WHERE at >= @f AND at < @t) AS invoices,
    (SELECT ISNULL(SUM(qty),0) FROM sale_items si JOIN sales s ON s.id = si.sale_id WHERE s.at >= @f AND s.at < @t) AS items,
    (SELECT ISNULL(SUM(total),0) FROM sales WHERE at >= @f AND at < @t) AS sales,
    (SELECT ISNULL(SUM(cost_total),0) FROM sales WHERE at >= @f AND at < @t) AS cost,
    (SELECT ISNULL(SUM(profit),0) FROM sales WHERE at >= @f AND at < @t) AS gross,
    (SELECT ISNULL(SUM(total),0) FROM returns WHERE at >= @f AND at < @t) AS returns_total,
    (SELECT ISNULL(SUM(profit),0) FROM returns WHERE at >= @f AND at < @t) AS returns_profit,
    (SELECT ISNULL(SUM(amount),0) FROM expenses WHERE at >= @f AND at < @t) AS expenses,
    (SELECT ISNULL(SUM(amount),0) FROM salaries WHERE at >= @f AND at < @t) AS salaries,
    (SELECT ISNULL(SUM(cost),0) FROM damaged WHERE at >= @f AND at < @t) AS damaged,
    (SELECT ISNULL(SUM(amount_in - amount_out),0) FROM cash_moves) AS cash_now`;

const QUERIES = {
  // catalogue
  products:      () => run(`SELECT p.*, c.name AS category FROM products p LEFT JOIN categories c ON c.id = p.category_id WHERE p.active = 1 ORDER BY p.name`),
  productByCode: ({ code }) => run(`SELECT TOP 1 p.* FROM products p LEFT JOIN barcodes b ON b.product_id = p.id WHERE b.code = @code OR p.code = @code`, { code }),
  categories:    () => run(`SELECT * FROM categories WHERE visible = 1 ORDER BY sort`),
  bestSellers:   () => run(`SELECT TOP 9 p.id, p.name, p.price, p.orig_brand, p.qty, SUM(si.qty) AS sold FROM sale_items si JOIN sales s ON s.id = si.sale_id JOIN products p ON p.id = si.product_id WHERE s.at >= DATEADD(DAY,-30,SYSDATETIME()) GROUP BY p.id, p.name, p.price, p.orig_brand, p.qty ORDER BY sold DESC`),
  searchProducts:({ q }) => run(`SELECT TOP 40 * FROM products WHERE active = 1 AND (name LIKE @q OR orig_brand LIKE @q OR code LIKE @q) ORDER BY name`, { q: '%' + q + '%' }),
  lowStock:      () => run(`SELECT * FROM v_low_stock ORDER BY qty, sold30 DESC`),
  dormant:       () => run(`SELECT * FROM v_dormant ORDER BY days_idle DESC`),
  priceHistory:  ({ productId }) => run(`SELECT * FROM price_history WHERE product_id = @productId ORDER BY at`, { productId }),
  audit:         ({ days = 30 }) => run(`SELECT TOP 500 * FROM audit_log WHERE at >= DATEADD(DAY, -@days, SYSDATETIME()) ORDER BY id DESC`, { days }),
  customer:      ({ phone }) => run(`SELECT TOP 1 c.*, (SELECT TOP 3 si.name + N' (' + CONVERT(NVARCHAR(10), s.at, 23) + N')' FROM sales s JOIN sale_items si ON si.sale_id = s.id WHERE s.customer_id = c.id ORDER BY s.at DESC FOR JSON PATH) AS last FROM customers c WHERE phone = @phone`, { phone }),
  // money
  cashMoves:     ({ from, to }) => run(`SELECT * FROM cash_moves WHERE at >= @from AND at < @to ORDER BY id`, { from, to }),
  closings:      () => run(`SELECT TOP 120 * FROM closings ORDER BY id DESC`),
  profit:        ({ from, to }) => run(PROFIT_SQL, { f: from, t: to }).then(r => r[0]),
  fixedCosts:    () => run(`SELECT id, name, type, amount, period, pay_day AS payDay, off_day AS offDay, active, from_date AS [from] FROM fixed_costs ORDER BY id`),
  // merged from PerfumePOS
  purchases:     () => run(`SELECT TOP 200 p.at, c.name AS company, p.invoice, p.total, p.paid, p.currency FROM purchases p LEFT JOIN companies c ON c.id = p.company_id ORDER BY p.id DESC`),
  companies:     () => run(`SELECT * FROM v_company_balance ORDER BY name`),
  companyStatement: ({ id }) => run(`
    SELECT at, N'کڕین' AS kind, invoice AS ref, total AS debit, paid AS credit FROM purchases WHERE company_id = @id
    UNION ALL SELECT at, N'قەرزی دەستی', note, amount, 0 FROM company_debts WHERE company_id = @id
    UNION ALL SELECT at, N'پێدان', note, 0, amount FROM company_payments WHERE company_id = @id
    UNION ALL SELECT at, N'گەڕانەوەی کڕین', note, 0, total FROM purchase_returns WHERE company_id = @id
    ORDER BY at`, { id }),
  brands:        () => run(`SELECT * FROM brands WHERE active = 1 ORDER BY name`),
  employees:     () => run(`SELECT e.*, (SELECT MAX(at) FROM salaries WHERE employee_id = e.id) AS last_paid FROM employees e WHERE active = 1 ORDER BY name`),
  salaries:      ({ days = 60 }) => run(`SELECT TOP 200 * FROM salaries WHERE at >= DATEADD(DAY, -@days, SYSDATETIME()) ORDER BY id DESC`, { days }),
  expenses:      ({ from, to }) => run(`SELECT * FROM expenses WHERE at >= @from AND at < @to ORDER BY id DESC`, { from, to }),
  offersList:    () => run(`SELECT o.*, p.name AS product FROM offers o LEFT JOIN products p ON p.id = o.product_id ORDER BY o.id DESC`),
  customers:     () => run(`SELECT * FROM v_customer_balance ORDER BY name`),
  customerDebts: ({ id }) => run(`SELECT * FROM customer_debts WHERE customer_id = @id ORDER BY at`, { id }),
  boxes:         () => run(`SELECT * FROM v_box_balance ORDER BY id`),
  users:         () => run(`SELECT id, name, role, perms, active FROM users ORDER BY id`),
  settings:      () => run(`SELECT k, v FROM settings`),
  expired:       ({ days = 60 }) => run(`SELECT id, name, qty, expire, DATEDIFF(DAY, SYSDATETIME(), expire) AS days_left FROM products WHERE active = 1 AND expire IS NOT NULL AND expire <= DATEADD(DAY, @days, SYSDATETIME()) ORDER BY expire`, { days }),
  outOfStock:    () => run(`SELECT p.id, p.name, c.name AS company FROM products p LEFT JOIN companies c ON c.id = p.company_id WHERE p.active = 1 AND p.qty <= 0 ORDER BY p.name`),
  noBarcode:     () => run(`SELECT id, name FROM products p WHERE active = 1 AND (code IS NULL OR code = '') AND NOT EXISTS (SELECT 1 FROM barcodes b WHERE b.product_id = p.id)`),
  saleByNo:      ({ no }) => run(`SELECT s.*, (SELECT product_id, name, qty, price, cost FROM sale_items WHERE sale_id = s.id FOR JSON PATH) AS lines FROM sales s WHERE invoice_no = @no`, { no })
};

/* ---------- writes that must be atomic ---------- */
async function saveSale(s) {
  const tx = new sql.Transaction(pool); await tx.begin();
  try {
    const q = text => { const r = new sql.Request(tx); return { r, go: () => r.query(text) }; };
    let { r, go } = q(`UPDATE settings SET v = CAST(CAST(v AS INT) + 1 AS NVARCHAR) OUTPUT CAST(deleted.v AS INT) AS no WHERE k = 'next_invoice'`);
    const no = (await go()).recordset[0].no;
    ({ r, go } = q(`INSERT INTO sales(invoice_no, user_id, customer_id, subtotal, discount, offer_discount, total, cost_total, profit, received, printed)
                    OUTPUT inserted.id VALUES (@no, @u, @c, @sub, @d, @od, @tot, @cost, @pr, @rec, @p)`));
    r.input('no', no).input('u', s.userId).input('c', s.customerId || null).input('sub', s.subtotal).input('d', s.discount).input('od', s.offerDiscount || 0)
     .input('tot', s.total).input('cost', s.costTotal).input('pr', s.total - s.costTotal).input('rec', s.received || s.total).input('p', s.printed ? 1 : 0);
    const id = (await go()).recordset[0].id;
    for (const l of s.lines) {
      ({ r, go } = q(`INSERT INTO sale_items(sale_id, product_id, name, qty, price, discount, cost, profit) VALUES (@s, @p, @n, @q, @pr, @d, @c, @pf);
                      UPDATE products SET qty = qty - @q WHERE id = @p`));
      r.input('s', id).input('p', l.productId).input('n', l.name).input('q', l.qty).input('pr', l.price).input('d', l.discount || 0).input('c', l.cost).input('pf', l.qty * (l.price - l.cost) - (l.discount || 0));
      await go();
    }
    ({ r, go } = q(`INSERT INTO cash_moves(kind, ref_id, description, amount_in, user_id) VALUES ('sale', @id, @desc, @amt, @u)`));
    r.input('id', id).input('desc', s.lines.map(l => l.name + ' ×' + l.qty).join('، ')).input('amt', s.total).input('u', s.userId);
    await go();
    await tx.commit();
    return { ok: true, invoiceNo: no, saleId: id };
  } catch (e) { await tx.rollback(); throw e; }
}

async function adjustStock(changes, user) {   // (گۆڕینی مادە) + audit log (18)
  const tx = new sql.Transaction(pool); await tx.begin();
  try {
    for (const c of changes) {
      const r = new sql.Request(tx);
      r.input('id', c.productId).input('q', c.qty).input('p', c.price).input('b', c.priceBox).input('e', c.expire || null).input('u', user.id).input('un', user.name)
       .input('n', c.name).input('oq', String(c.old.qty)).input('op', String(c.old.price)).input('why', c.reason).input('t', c.reason.includes('تێستەر') ? Math.max(0, c.old.qty - c.qty) : 0);
      await r.query(`
        UPDATE products SET qty = @q, price = @p, price_box = @b, expire = @e, tester_qty = tester_qty + @t WHERE id = @id;
        IF @oq <> CAST(@q AS NVARCHAR) INSERT INTO audit_log(user_id, user_name, product_id, target, kind, old_value, new_value, reason) VALUES (@u, @un, @id, @n, N'گۆڕینی بڕ', @oq, CAST(@q AS NVARCHAR), @why);
        IF @op <> CAST(CAST(@p AS INT) AS NVARCHAR) INSERT INTO audit_log(user_id, user_name, product_id, target, kind, old_value, new_value, reason) VALUES (@u, @un, @id, @n, N'گۆڕینی نرخ', @op, CAST(CAST(@p AS INT) AS NVARCHAR), @why);`);
    }
    await tx.commit(); return { ok: true };
  } catch (e) { await tx.rollback(); throw e; }
}

async function closeDay(c) {                   // (13, 14, 15)
  await run(`INSERT INTO cash_moves(kind, description, amount_out, user_id) VALUES ('out', @d, @a, @u);
             INSERT INTO closings(user_id, invoices, items, sales, returns, expenses, fixed_costs, net_profit, taken, left_in_box)
             VALUES (@u, @inv, @it, @s, @r, @e, @fx, @n, @a, @l)`,
    { d: c.note || 'ڕاکێشانی کۆتایی ڕۆژ', a: c.taken, u: c.userId, inv: c.invoices, it: c.items, s: c.sales, r: c.returns, e: c.expenses, fx: c.fixed || 0, n: c.netProfit, l: c.left });
  return { ok: true };
}

async function checkLogin(name, pass, hash) {
  const u = (await run(`SELECT * FROM users WHERE name = @name AND active = 1`, { name }))[0];
  if (!u || u.pass_hash !== hash(pass)) return null;
  return { id: u.id, name: u.name, role: u.role };
}

/* ---------- other writes (merged from PerfumePOS). Each one runs in a transaction. ---------- */
async function tx(fn) {
  const t = new sql.Transaction(pool); await t.begin();
  const q = (text, params = {}) => { const r = new sql.Request(t); for (const [k, v] of Object.entries(params)) r.input(k, v); return r.query(text).then(x => x.recordset || []); };
  try { const out = await fn(q); await t.commit(); return Object.assign({ ok: true }, out || {}); }
  catch (e) { await t.rollback(); throw e; }
}
const money = (q, kind, desc, inn, out, u, box = 1, ref = null) =>
  q(`INSERT INTO cash_moves(kind, ref_id, description, amount_in, amount_out, user_id, box_id) VALUES (@k, @r, @d, @i, @o, @u, @b)`, { k: kind, r: ref, d: desc, i: inn || 0, o: out || 0, u, b: box || 1 });

const ACTS = {
  // purchase invoice: stock in, new cost/price, company debt for the unpaid part
  purchase: (a, u) => tx(async q => {
    const id = (await q(`INSERT INTO purchases(company_id, invoice, currency, usd_rate, total, paid, due_date, user_id) OUTPUT inserted.id
                         VALUES (@c, @inv, @cur, @rate, @tot, @paid, @due, @u)`, { c: a.companyId, inv: a.invoice || '', cur: a.currency || 'IQD', rate: a.usdRate || null, tot: a.total, paid: a.paid || 0, due: a.dueDate || null, u: u.id }))[0].id;
    for (const l of a.lines) {
      await q(`INSERT INTO purchase_items(purchase_id, product_id, qty, cost, price) VALUES (@p, @pr, @q, @c, @s);
               UPDATE products SET qty = qty + @q, cost = @ciqd, price = CASE WHEN @s > 0 THEN @s ELSE price END, company_id = @co WHERE id = @pr;
               INSERT INTO price_history(product_id, company_id, cost, currency, usd_rate, cost_iqd, price, source) VALUES (@pr, @co, @c, @cur, @rate, @ciqd, @s, 'purchase')`,
        { p: id, pr: l.productId, q: l.qty, c: l.cost, s: l.price || 0, ciqd: l.costIqd || l.cost, co: a.companyId, cur: a.currency || 'IQD', rate: a.usdRate || null });
    }
    if (a.paid > 0) await money(q, 'purchase', 'کڕین — ' + (a.companyName || ''), 0, a.paid, u.id, a.boxId, id);
    return { id };
  }),
  purchaseReturn: (a, u) => tx(async q => {
    const id = (await q(`INSERT INTO purchase_returns(company_id, currency, total, note, user_id) OUTPUT inserted.id VALUES (@c, @cur, @t, @n, @u)`, { c: a.companyId, cur: a.currency || 'IQD', t: a.total, n: a.note || '', u: u.id }))[0].id;
    for (const l of a.lines) await q(`INSERT INTO purchase_return_items(return_id, product_id, qty, cost) VALUES (@r, @p, @q, @c); UPDATE products SET qty = qty - @q WHERE id = @p`, { r: id, p: l.productId, q: l.qty, c: l.cost });
    return { id };
  }),
  saveCompany: (a) => a.id ? run(`UPDATE companies SET name=@n, phone=@p, whatsapp=@w, address=@ad WHERE id=@id`, { id: a.id, n: a.name, p: a.phone || '', w: a.whatsapp || '', ad: a.address || '' })
                           : run(`INSERT INTO companies(name, phone, whatsapp, address) VALUES (@n, @p, @w, @ad)`, { n: a.name, p: a.phone || '', w: a.whatsapp || '', ad: a.address || '' }),
  payCompany: (a, u) => tx(async q => {
    await q(`INSERT INTO company_payments(company_id, amount, currency, note, user_id) VALUES (@c, @a, @cur, @n, @u)`, { c: a.companyId, a: a.amount, cur: a.currency || 'IQD', n: a.note || '', u: u.id });
    await money(q, 'company', 'دانەوەی قەرز — ' + (a.companyName || ''), 0, a.amountIqd || a.amount, u.id, a.boxId);
  }),
  companyDebt: (a, u) => run(`INSERT INTO company_debts(company_id, amount, currency, note, user_id) VALUES (@c, @a, @cur, @n, @u)`, { c: a.companyId, a: a.amount, cur: a.currency || 'IQD', n: a.note || '', u: u.id }),
  expense: (a, u) => tx(async q => {
    await q(`INSERT INTO expenses(type, amount, note, user_id) VALUES (@t, @a, @n, @u)`, { t: a.type, a: a.amount, n: a.note || '', u: u.id });
    await money(q, 'expense', a.type + (a.note ? ' — ' + a.note : ''), 0, a.amount, u.id, a.boxId);
  }),
  salary: (a, u) => tx(async q => {
    await q(`INSERT INTO salaries(employee, employee_id, month, amount, user_id) VALUES (@e, @id, @m, @a, @u)`, { e: a.employee, id: a.employeeId || null, m: a.period || '', a: a.amount, u: u.id });
    await money(q, 'salary', 'مووچە — ' + a.employee, 0, a.amount, u.id, a.boxId);
  }),
  saveEmployee: (a) => a.id ? run(`UPDATE employees SET name=@n, phone=@p, salary=@s, period=@pe, active=@ac WHERE id=@id`, { id: a.id, n: a.name, p: a.phone || '', s: a.salary || 0, pe: a.period || 'week', ac: a.active === false ? 0 : 1 })
                            : run(`INSERT INTO employees(name, phone, salary, period) VALUES (@n, @p, @s, @pe)`, { n: a.name, p: a.phone || '', s: a.salary || 0, pe: a.period || 'week' }),
  damaged: (a, u) => tx(async q => {
    await q(`INSERT INTO damaged(product_id, qty, cost, note, user_id) VALUES (@p, @q, @c, @n, @u); UPDATE products SET qty = qty - @q WHERE id = @p`, { p: a.productId, q: a.qty, c: a.cost, n: a.note || '', u: u.id });
    await q(`INSERT INTO audit_log(user_id, user_name, product_id, target, kind, old_value, new_value, reason) VALUES (@u, @un, @p, @t, N'خراپبوو', '', CAST(@q AS NVARCHAR), @n)`, { u: u.id, un: u.name, p: a.productId, t: a.name || '', q: a.qty, n: a.note || '' });
  }),
  saveOffer: (a) => a.id ? run(`UPDATE offers SET name=@n, product_id=@p, qty=@q, bundle_price=@b, from_date=@f, to_date=@t, active=@ac WHERE id=@id`, { id: a.id, n: a.name, p: a.productId || null, q: a.qty, b: a.price, f: a.from || null, t: a.to || null, ac: a.active === false ? 0 : 1 })
                         : run(`INSERT INTO offers(name, product_id, qty, bundle_price, from_date, to_date) VALUES (@n, @p, @q, @b, @f, @t)`, { n: a.name, p: a.productId || null, q: a.qty, b: a.price, f: a.from || null, t: a.to || null }),
  deleteOffer: (a) => run(`DELETE FROM offers WHERE id = @id`, { id: a.id }),
  saveCustomer: (a) => a.id ? run(`UPDATE customers SET name=@n, phone=@p, birth_date=@b, fav_scent=@f, is_vip=@v, note=@no WHERE id=@id`, { id: a.id, n: a.name, p: a.phone, b: a.birth || null, f: a.fav || '', v: a.vip ? 1 : 0, no: a.note || '' })
                            : run(`INSERT INTO customers(name, phone, birth_date, fav_scent, is_vip, note) VALUES (@n, @p, @b, @f, @v, @no)`, { n: a.name, p: a.phone, b: a.birth || null, f: a.fav || '', v: a.vip ? 1 : 0, no: a.note || '' }),
  customerDebt: (a, u) => tx(async q => {      // kind: debt (old debt written in) | pay (customer paid back)
    await q(`INSERT INTO customer_debts(customer_id, amount, kind, note, user_id) VALUES (@c, @a, @k, @n, @u)`, { c: a.customerId, a: a.amount, k: a.kind, n: a.note || '', u: u.id });
    if (a.kind === 'pay') await money(q, 'debt', 'وەرگرتنەوەی قەرز — ' + (a.customerName || ''), a.amount, 0, u.id, a.boxId);
  }),
  boxTransfer: (a, u) => tx(async q => {
    await money(q, 'transfer', 'گواستنەوە بۆ ' + a.toName, 0, a.amount, u.id, a.from);
    await money(q, 'transfer', 'گواستنەوە لە ' + a.fromName, a.amount, 0, u.id, a.to);
  }),
  cancelSale: (a, u) => tx(async q => {
    const s = (await q(`SELECT * FROM sales WHERE invoice_no = @no AND cancelled = 0`, { no: a.no }))[0];
    if (!s) throw new Error('پسوڵەکە نەدۆزرایەوە یان پێشتر هەڵوەشێنراوەتەوە');
    await q(`UPDATE sales SET cancelled = 1, cancel_reason = @r WHERE id = @id;
             UPDATE p SET p.qty = p.qty + si.qty FROM products p JOIN sale_items si ON si.product_id = p.id WHERE si.sale_id = @id;
             INSERT INTO returns(sale_id, user_id, total, profit, reason) VALUES (@id, @u, @t, @pf, N'هەڵوەشاندنەوە: ' + @r)`, { id: s.id, r: a.reason || '', u: u.id, t: s.total, pf: s.profit });
    await money(q, 'return', 'هەڵوەشاندنەوەی پسوڵە ' + a.no, 0, s.total, u.id, s.box_id);
  }),
  swap: (a, u) => tx(async q => {              // perfume exchange: give back one, take another, pay the difference
    const rid = (await q(`INSERT INTO returns(sale_id, user_id, total, profit, reason) OUTPUT inserted.id VALUES (NULL, @u, @t, @pf, N'گۆڕینەوە')`, { u: u.id, t: a.back.price, pf: a.back.price - a.back.cost }))[0].id;
    await q(`INSERT INTO return_items(return_id, product_id, name, qty, price, profit) VALUES (@r, @p, @n, 1, @pr, @pf); UPDATE products SET qty = qty + 1 WHERE id = @p`, { r: rid, p: a.back.productId, n: a.back.name, pr: a.back.price, pf: a.back.price - a.back.cost });
    const no = (await q(`UPDATE settings SET v = CAST(CAST(v AS INT) + 1 AS NVARCHAR) OUTPUT CAST(deleted.v AS INT) AS no WHERE k = 'next_invoice'`))[0].no;
    const sid = (await q(`INSERT INTO sales(invoice_no, user_id, subtotal, total, cost_total, profit, received) OUTPUT inserted.id VALUES (@no, @u, @p, @p, @c, @p - @c, @p)`, { no, u: u.id, p: a.take.price, c: a.take.cost }))[0].id;
    await q(`INSERT INTO sale_items(sale_id, product_id, name, qty, price, cost, profit) VALUES (@s, @p, @n, 1, @pr, @c, @pr - @c); UPDATE products SET qty = qty - 1 WHERE id = @p`, { s: sid, p: a.take.productId, n: a.take.name, pr: a.take.price, c: a.take.cost });
    const diff = a.take.price - a.back.price;
    await q(`INSERT INTO swaps(return_id, sale_id, difference, user_id) VALUES (@r, @s, @d, @u)`, { r: rid, s: sid, d: diff, u: u.id });
    if (diff) await money(q, 'swap', 'گۆڕینەوە: ' + a.back.name + ' ← ' + a.take.name, Math.max(diff, 0), Math.max(-diff, 0), u.id);
    return { invoiceNo: no };
  }),
  setBarcode: (a) => run(`UPDATE products SET code = @c WHERE id = @id AND (code IS NULL OR code = '')`, { id: a.id, c: a.code }),
  saveUser: (a, u, hash) => a.id
      ? run(`UPDATE users SET role=@r, perms=@p, active=@ac${a.pass ? ', pass_hash=@h' : ''} WHERE id=@id`, { id: a.id, r: a.role, p: JSON.stringify(a.perms || []), ac: a.active === false ? 0 : 1, h: a.pass ? hash(a.pass) : '' })
      : run(`INSERT INTO users(name, pass_hash, role, perms) VALUES (@n, @h, @r, @p)`, { n: a.name, h: hash(a.pass), r: a.role || 'cashier', p: JSON.stringify(a.perms || []) }),
  setting: (a) => run(`MERGE settings AS t USING (SELECT @k AS k) s ON t.k = s.k WHEN MATCHED THEN UPDATE SET v = @v WHEN NOT MATCHED THEN INSERT(k, v) VALUES (@k, @v);`, { k: a.k, v: String(a.v) })
};
/* the cashier may only do these; everything else needs the owner */
const CASHIER_ACTS = ['expense', 'customerDebt', 'saveCustomer', 'swap', 'setBarcode'];

module.exports = { getPool: () => pool, connect, run, QUERIES, ACTS, CASHIER_ACTS, saveSale, adjustStock, closeDay, checkLogin, PROFIT_SQL };
