/* The only functions the screens can call (safe bridge) */
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('api', {
  minimize: () => ipcRenderer.invoke('win:min'),
  quit: () => ipcRenderer.invoke('win:quit'),
  reloadData: () => ipcRenderer.invoke('store:reload'),
  refocus: () => ipcRenderer.invoke('win:refocus'),
  printRc: html => ipcRenderer.invoke('prn:rc', html),
  full: on => ipcRenderer.invoke('win:full', on),
  openExternal: url => ipcRenderer.invoke('open:external', url),
  shop: () => ipcRenderer.invoke('config:shop'),
  login: (name, pass) => ipcRenderer.invoke('auth:login', name, pass),
  users: () => ipcRenderer.invoke('auth:users'),
  checkPin: pin => ipcRenderer.invoke('auth:checkPin', pin),
  query: (name, params) => ipcRenderer.invoke('db:query', name, params),
  saveSale: sale => ipcRenderer.invoke('sale:save', sale),
  adjustStock: changes => ipcRenderer.invoke('stock:adjust', changes),
  closeDay: c => ipcRenderer.invoke('day:close', c),
  backupNow: () => ipcRenderer.invoke('backup:now'),
  act: (op, args) => ipcRenderer.invoke('db:act', op, args),
  me: () => ipcRenderer.invoke('auth:me'),
  storeLoad: () => ipcRenderer.invoke('store:load'),
  storeTx: ops => ipcRenderer.invoke('store:tx', ops),
  tg: text => ipcRenderer.invoke('tg:send', text),
  helpSend: (q, who, voice) => ipcRenderer.invoke('help:send', q, who, voice),
  helpReplies: ids => ipcRenderer.invoke('help:replies', ids),
  hash: s => ipcRenderer.invoke('sys:hash', s)
});
