/* Navigation + window buttons shared by every screen.
   Inside the desktop app window.api exists (from preload.js); in a normal browser it falls back to links. */
(function () {
  const api = window.api || {};
  const go = page => { location.href = page; };
  if (typeof window.go !== 'function') window.go = go;      // modules.html has its own go(section)

  // home screen: buttons, side tiles and menu open the right screens
  const MAP = {
    'فرۆشتن':'sale.html', 'تۆمارکردنی مادە':'item.html', 'مادە تەواوبووەکان':'modules.html?m=out', 'زانیاری کۆگا':'stock.html',
    'خەزێنە':'modules.html?m=box', 'دەخیلەی دوکان':'modules.html?m=box', 'سندوق':'modules.html?m=box', 'جۆری مادە':'modules.html?m=cats', 'جەردی کۆگا':'modules.html?m=count', 'ڕاکێشانی پارە':'modules.html?m=box', 'دانانەوەی پارە':'modules.html?m=box', 'ڕاپۆرتی ئەمڕۆ':'modules.html?m=today',
    'گەڕاندنەوەی فرۆشتن':'modules.html?m=sret', 'گۆڕینەوەی بۆن':'modules.html?m=swap',
    'گۆڕینی مادە':'modules.html?m=bulk', 'کڕیارەکان':'modules.html?m=cust', 'پاراستنی سیستەم (Backup)':'#backup',
    'زانیاری مادەکان':'stock.html', 'بەشی ڕاپۆرتەکان':'modules.html?m=rep', 'پسوڵەی خێرا':'sale.html',
    // parts merged from PerfumePOS (one screen: modules.html)
    'خەرجییەکان':'modules.html?m=exp', 'تۆمارکردنی خەرجی':'modules.html?m=exp', 'پێدانی مووچە':'modules.html?m=sal',
    'کڕینی مادە':'modules.html?m=buy', 'گەڕانەوەی کڕین':'modules.html?m=bret', 'کۆمپانیاکان':'modules.html?m=whl',
    'کەشفی حسابی کۆمپانیا':'modules.html?m=whl', 'دانەوەی قەرزی کۆمپانیا':'modules.html?m=cpay',
    'وەرگرتنەوەی قەرز':'modules.html?m=debt', 'کەشفی حسابی کڕیار':'modules.html?m=debt',
    'ئۆفەری مادە':'modules.html?m=offers', 'دروستکردنی ئۆفەری تایبەت':'modules.html?m=offers',
    'تۆمارکردنی مادەی خراپبوو':'modules.html?m=dmg', 'دروستکردنی باڕکۆد':'modules.html?m=bar', 'مادە بەسەرچووەکان':'modules.html?m=expired'
  };
  document.querySelectorAll('#grid .btn, .tile, #quick').forEach(el => {
    const t = (el.childNodes.length ? [...el.childNodes].filter(n => n.nodeType === 3).map(n => n.textContent).join('') : el.textContent).trim();
    const dest = MAP[t];
    if (!dest || el.id === 'm-settings') return;
    el.dataset.dest = dest;
    el.addEventListener('click', () => {
      if (dest === '#backup') { if (api.backupNow) api.backupNow().then(r => alert(r.ok ? '✓ Backup کرا: ' + r.file : '⚠️ ' + r.error)); else alert('Backup تەنها لە ناو بەرنامەکەدا کار دەکات'); return; }
      if (window.__homeGoto) window.__homeGoto(dest); else go(dest);
    });
  });

  // every screen (except home / login) gets a clear "back to home" button in the top-left corner
  const here = location.pathname.split('/').pop();
  if (here !== 'home.html' && here !== 'login.html' && !document.getElementById('gohome')) {
    const b = document.createElement('div');
    b.id = 'gohome'; b.textContent = '🏠 گەڕانەوە بۆ سەرەکی (Esc)';
    b.style.cssText = 'position:fixed;left:8px;top:6px;z-index:9999;background:#B42318;color:#fff;padding:6px 14px;border-radius:8px;cursor:pointer;font:15px NRT,Tahoma,sans-serif;-webkit-app-region:no-drag;box-shadow:0 2px 8px rgba(0,0,0,.35)';
    b.onclick = () => go('home.html');
    document.body.appendChild(b);
  }

  // after a native alert/confirm Windows Electron stops typing into inputs → give focus back
  ['alert','confirm'].forEach(k => { const f = window[k].bind(window); window[k] = m => { const r = f(m); try { window.api && api.refocus && api.refocus(); } catch (e) {} return r; }; });

  // Escape = back to home (except on home / login / when a dialog is open)
  addEventListener('keydown', e => {
    if (e.key !== 'Escape') return;
    const page = location.pathname.split('/').pop();
    const dialogOpen = document.querySelector('.show, #lwrap[style*="block"], #bs-dlg, #pbox');
    if (!dialogOpen && page !== 'home.html' && page !== 'login.html') go('home.html');
  });

  /* ===== one toolbar on every screen: ✕ exit · − minimise · 🔒 lock · ⌨️ keyboard · ↩️ undo · 🖥️ fit ===== */
  const here2 = location.pathname.split('/').pop() || 'home.html', isLogin = here2 === 'login.html';
  const CC = () => window.C;
  const can = k => { try { return CC() && CC().can(k); } catch (e) { return false; } };
  const css = document.createElement('style'); css.textContent = `
    .wb,.winbtn{display:none!important}
    #bs-bar{position:fixed;top:0;right:0;z-index:99990;display:flex;flex-direction:row-reverse;gap:2px;padding:2px 4px;-webkit-app-region:no-drag;font-family:NRT,Tahoma,sans-serif}
    #bs-bar .bb{min-width:62px;height:36px;border-radius:7px;background:rgba(0,0,0,.28);color:#fff;display:flex;flex-direction:column;align-items:center;justify-content:center;cursor:pointer;font-size:15px;line-height:1;padding:0 4px}
    #bs-bar .bb small{font-size:10px;margin-top:3px;opacity:.95;white-space:nowrap;overflow:visible}
    #bs-bar .bb:hover{background:rgba(0,0,0,.45)} #bs-bar .bb.tx:hover{background:#C62828} #bs-bar .bb.dis{opacity:.35}
    #jump{right:auto!important;left:228px!important}
    html.bs-fill body{background:var(--navy,#1B2747)}
    html.bs-fill #bs-bar{padding:1px 3px} html.bs-fill #bs-bar .bb{height:25px;min-width:34px;flex-direction:row;gap:4px;font-size:13px} html.bs-fill #bs-bar .bb small{margin:0;font-size:10px}
    html.bs-fill #gohome{top:1px!important;padding:3px 10px!important;font-size:13px!important}
    #bs-dlg{position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:99995;display:flex;align-items:center;justify-content:center;font-family:NRT,Tahoma,sans-serif}
    #bs-dlg .w{background:#fff;color:#111;border-radius:14px;padding:18px 22px;max-width:460px;width:90%;box-shadow:0 20px 50px rgba(0,0,0,.4);font-size:15px;line-height:1.7}
    #bs-dlg .w h3{margin:0 0 6px;font-size:18px} #bs-dlg .bt{display:flex;gap:8px;margin-top:14px} #bs-dlg .bt div{flex:1;height:42px;border-radius:8px;display:flex;align-items:center;justify-content:center;cursor:pointer;color:#fff;font-size:16px}
    #bs-osk{position:fixed;left:0;right:0;bottom:0;z-index:99993;background:#1d2230;padding:6px;display:none;direction:ltr;font-family:NRT,Tahoma,sans-serif;box-shadow:0 -6px 20px rgba(0,0,0,.35)}
    #bs-osk .r{display:flex;gap:5px;justify-content:center;margin:4px 0} #bs-osk .ok{min-width:52px;height:46px;border-radius:7px;background:#3a4255;color:#fff;display:flex;align-items:center;justify-content:center;font-size:21px;cursor:pointer;user-select:none;padding:0 8px}
    #bs-osk .ok:active{background:#5b6680} #bs-osk .ok.w{min-width:340px} #bs-osk .ok.m{background:#2b6cb0;font-size:16px} #bs-osk .ok.c{background:#9b2c2c;font-size:16px}`;
  document.head.appendChild(css);
  function dlg(title, html, yes, yesText, noText) { const o = document.createElement('div'); o.id = 'bs-dlg';
    o.innerHTML = `<div class="w"><h3>${title}</h3><div>${html}</div><div class="bt">${yes ? `<div style="background:#166534" id="bdy">${yesText || '✅ بەڵێ'}</div>` : ''}<div style="background:#6b7280" id="bdn">${noText || (yes ? '❌ نەخێر' : 'داخستن')}</div></div></div>`;
    document.body.appendChild(o); o.querySelector('#bdn').onclick = () => o.remove(); if (yes) o.querySelector('#bdy').onclick = () => { o.remove(); yes(); }; }
  const esc = t => String(t == null ? '' : t).replace(/[&<>"]/g, c => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;' }[c]));
  function quitApp() { dlg('✕ دەرچوون', 'بەرنامەکە دابخرێت؟', () => { try { CC() && CC().U && CC().logout(); } catch (e) {} setTimeout(() => api.quit ? api.quit() : window.close(), 250); }); }
  function lockApp() { dlg('🔒 قفڵکردن', 'بەرنامەکە داناخرێت؛ دەگەڕێتەوە بۆ فۆرمی چوونەژوورەوە و دەبێت دووبارە وشەی نهێنی بنووسرێت.', () => { try { CC().logout(); } catch (e) {} setTimeout(() => location.href = 'login.html', 250); }, '🔒 قفڵ بکە'); }
  function undoAsk() { if (!can('undo')) return dlg('🔒', 'دەسەڵاتی «گەڕانەوەی هەنگاوی پێشوو»ت نییە.');
    const e = CC().lastUndo();
    if (!e) return dlg('↩️ گەڕانەوەی دوایین هەنگاو', 'ئەم دوگمەیە دوایین کارێک کە داتای گۆڕیوە هەڵدەوەشێنێتەوە (فرۆشتن، سڕینەوە، گۆڕینی نرخ، کڕین...).<br><br><b>هیچ هەنگاوێک نییە بۆ گەڕانەوە.</b>');
    const d = new Date(e.t), p2 = n => String(n).padStart(2, '0');
    dlg('↩️ گەڕانەوەی دوایین هەنگاو', `ئەم دوگمەیە دوایین کارێک کە داتای گۆڕیوە هەڵدەوەشێنێتەوە، وەک ئەوەی هەرگیز نەکرابێت.<br><br><b>دوایین هەنگاو:</b> ${esc(e.a)}<br><span style="color:#666">لەلایەن ${esc(e.u)} · کاتژمێر ${p2(d.getHours())}:${p2(d.getMinutes())} · ${p2(d.getDate())}/${p2(d.getMonth() + 1)}</span><br><br>ئایا دەتەوێت ئەم هەنگاوە بگەڕێنیتەوە؟`,
      async () => { await CC().undo(); location.reload(); }, '✅ بەڵێ، بیگەڕێنەوە', '❌ نەخێر'); }
  function fitAsk() { if (!can('theme') && !isLogin) return dlg('🔒', 'دەسەڵاتی «ڕووکار و دیزاین»ت نییە.');
    const on = window.bsFitMode && bsFitMode() === 'fill';
    dlg('🖥️ گونجاندنی دیزاینی بەرنامە لەم شاشەیە', on ? 'ئێستا بەرنامەکە هەموو شاشەکە پڕ دەکاتەوە. دەتەوێت بگەڕێتەوە بۆ قەبارەی ئاسایی؟' : 'هەموو بەشەکانی بەرنامە (نووسین، دوگمە، ئایکۆن) خۆیان لەگەڵ قەبارەی ئەم شاشەیە دەگونجێنن و هیچ لێوارێکی بەتاڵ نامێنێت. ئەم ڕێکخستنە تەنها بۆ ئەم کۆمپیوتەرەیە.',
      () => bsSetFit(on ? 'fit' : 'fill'), on ? '↺ قەبارەی ئاسایی' : '🖥️ بگونجێنە'); }
  const bar = document.createElement('div'); bar.id = 'bs-bar';
  const B = [['tx','✕','دەرچوون',quitApp],['tm','−','بچووککردنەوە',() => api.minimize && api.minimize()]];
  if (!isLogin) B.push(['tl','🔒','قفڵ',lockApp]);
  B.push(['tk','⌨️','کیبۆرد',() => osk()]);
  if (!isLogin) B.push(['tu','↩️','گەڕانەوە',undoAsk]);
  B.push(['tf','🖥️','شاشە',fitAsk]);
  // 🔄 refresh: read everything fresh from the database and redraw this screen
  B.push(['tr','🔄','ڕیفرێش',async () => { if (/sale\.html/.test(location.pathname) && document.querySelector('#lines .row') && !confirm('سەبەتەی فرۆشتن بەتاڵ دەبێتەوە. ڕیفرێش بکرێت؟')) return;
    try { if (window.api && api.reloadData) await api.reloadData(); } catch (e) {} location.reload(); }]);
  bar.innerHTML = B.map(b => `<div class="bb ${b[0]}" title="${b[2]}">${b[1]}<small>${b[2]}</small></div>`).join('');
  document.body.appendChild(bar); bar.querySelectorAll('.bb').forEach((el, k) => el.onclick = B[k][3]);
  setTimeout(() => { const u = bar.querySelector('.bb.tu'); if (u && !can('undo')) u.classList.add('dis'); }, 1500);
  addEventListener('keydown', e => { if (e.ctrlKey && (e.key === 'z' || e.key === 'Z') && !isLogin) { const a = document.activeElement; if (a && /^(INPUT|TEXTAREA)$/.test(a.tagName) && a.value) return; e.preventDefault(); undoAsk(); } });

  /* screen changed since the last fit → ask once */
  setTimeout(() => { try { const wh = localStorage.getItem('bs_fit_wh'), now = screen.width + 'x' + screen.height;
    if (wh && wh !== now && can('theme')) dlg('🖥️ شاشەکە گۆڕاوە', 'دەتەوێت دیزاینی بەرنامەکە لەگەڵ ئەم شاشە نوێیە بگونجێنم؟', () => bsSetFit('fill'), '✅ بەڵێ');
    if (wh !== now) localStorage.setItem('bs_fit_wh', now); } catch (e) {} }, 1200);

  /* ===== on-screen keyboard (Kurdish Sorani / English), only when the owner opens it ===== */
  let last = null, lang = 'ku', shift = false;
  addEventListener('focusin', e => { if (/^(INPUT|TEXTAREA)$/.test(e.target.tagName) && !e.target.closest('#bs-osk')) last = e.target; });
  const KU = [['1','2','3','4','5','6','7','8','9','0','⌫'],['ق','و','ە','ر','ت','ی','ێ','ئ','ۆ','پ'],['ا','س','ش','د','ف','گ','ه','ژ','ک','ل','ڵ'],['ز','خ','ج','چ','ڤ','ب','ن','م','ڕ','ع','غ','ح'],['⇄ EN','␣','،','.','⏎','✖']];
  const EN = [['1','2','3','4','5','6','7','8','9','0','⌫'],['q','w','e','r','t','y','u','i','o','p'],['a','s','d','f','g','h','j','k','l'],['⇧','z','x','c','v','b','n','m','-','@'],['⇄ کو','␣',',','.','⏎','✖']];
  function typeIn(ch) { const el = last; if (!el || !document.contains(el)) return; el.focus();
    if (ch === '⌫') { const a = el.selectionStart, b = el.selectionEnd; if (a == null) { el.value = el.value.slice(0, -1); } else if (a !== b) el.setRangeText('', a, b, 'end'); else if (a > 0) el.setRangeText('', a - 1, a, 'end'); }
    else if (ch === '⏎') { el.dispatchEvent(new KeyboardEvent('keydown', { key:'Enter', code:'Enter', keyCode:13, bubbles:true })); return; }
    else { try { el.setRangeText(ch, el.selectionStart, el.selectionEnd, 'end'); } catch (e) { el.value += ch; } }
    el.dispatchEvent(new Event('input', { bubbles:true })); }
  function drawOsk() { const k = document.getElementById('bs-osk'), L = lang === 'ku' ? KU : EN;
    k.innerHTML = L.map(r => `<div class="r">${r.map(c => `<div class="ok${c === '␣' ? ' w' : /⇄|⏎|⇧/.test(c) ? ' m' : c === '✖' ? ' c' : ''}" data-c="${c}">${c === '␣' ? (lang === 'ku' ? 'بۆشایی' : 'space') : lang === 'en' && shift && c.length === 1 ? c.toUpperCase() : c}</div>`).join('')}</div>`).join('');
    k.querySelectorAll('.ok').forEach(b => { b.onmousedown = e => e.preventDefault(); b.onclick = () => { const c = b.dataset.c;
      if (c.startsWith('⇄')) { lang = lang === 'ku' ? 'en' : 'ku'; drawOsk(); } else if (c === '⇧') { shift = !shift; drawOsk(); } else if (c === '✖') osk(false);
      else typeIn(c === '␣' ? ' ' : lang === 'en' && shift && c.length === 1 ? c.toUpperCase() : c); }; }); }
  function osk(show) { let k = document.getElementById('bs-osk'); if (!k) { k = document.createElement('div'); k.id = 'bs-osk'; document.body.appendChild(k); }
    const on = show == null ? k.style.display !== 'block' : show; k.style.display = on ? 'block' : 'none'; if (on) drawOsk(); }
  window.bsOsk = osk;

  /* ===== every price on every screen also shows its value in dollars, small, next to it ===== */
  const RATE = () => { try { return (CC() && CC().D.set && CC().D.set.rate) || 1680; } catch (e) { return 1680; } };
  const usd = v => '$' + (v / RATE()).toFixed(2);
  const SKIP = /^(INPUT|TEXTAREA|SELECT|OPTION|SCRIPT|STYLE|BUTTON)$/;
  const PRICE_SEL = '.prod .price, #lines .row > div:nth-child(3), #lines .row > div:nth-child(5), #sum, #rows .tr > div:nth-child(8), #rows .tr > div:nth-child(9), #rows .tr > div:nth-child(11), #t2, #t3, #t4';
  const mk = v => { const sp = document.createElement('span'); sp.className = 'bs-usd'; sp.textContent = ' ' + usd(v); sp.style.cssText = 'font-size:.68em;opacity:.65;font-weight:normal;margin-inline-start:3px;white-space:nowrap;direction:ltr;unicode-bidi:isolate;font-family:Arial,sans-serif'; return sp; };
  function usdify() { if (!CC() || !CC().D || !CC().D.set) return; const body = document.body; if (!body) return;
    // 1) any text like "25,000 د.ع"
    const w = document.createTreeWalker(body, NodeFilter.SHOW_TEXT, { acceptNode: n => (/\d\s*د\.ع/.test(n.nodeValue) && n.parentElement && !SKIP.test(n.parentElement.tagName) && !n.parentElement.closest('#bs-bar,#bs-osk,.bs-usd,#receipt,.rc,#rwrap') && !(n.nextSibling && n.nextSibling.className === 'bs-usd')) ? 1 : 3 });
    const L = []; while (w.nextNode()) L.push(w.currentNode);
    L.forEach(n => { if (/\$/.test(n.parentElement.textContent)) return; const m = n.nodeValue.match(/(-?\d[\d,]*)\s*د\.ع/); if (!m) return; const v = +m[1].replace(/,/g, ''); if (!v) return;
      const i = n.nodeValue.indexOf(m[0]) + m[0].length, rest = n.splitText(i); n.parentNode.insertBefore(mk(v), rest); });
    // 2) bare price numbers in the sale / stock screens
    document.querySelectorAll(PRICE_SEL).forEach(el => { if (el.closest('#receipt,.rc,#rwrap') || el.querySelector('.bs-usd') || /\$/.test(el.textContent)) return; const m = el.textContent.match(/-?\d[\d,]*/); if (!m) return; const v = +m[0].replace(/,/g, ''); if (!v) return; el.appendChild(mk(v)); }); }
  let ut = null; const usdLater = () => { clearTimeout(ut); ut = setTimeout(() => { obs.disconnect(); try { usdify(); } catch (e) {} obs.observe(document.body, { childList:true, subtree:true, characterData:true }); }, 120); };
  const obs = new MutationObserver(usdLater); obs.observe(document.body, { childList:true, subtree:true, characterData:true }); setTimeout(usdLater, 800);
})();
