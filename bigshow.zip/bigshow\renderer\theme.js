/* Shared appearance (colours, design style, font size) for every screen */
const THEMES = {
    classic: { name:'کلاسیک (کۆن)', primary:'#1B2747', primary2:'#2E3F6E', primary3:'#0F1730', bg:'#FFFFFF', navy:'#1B2747', navy2:'#1B2747', slate:'#1B2747', surface:'#FFFFFF', text:'#0F0F30', muted:'#47455E', line:'#D9D9E3', accent:'#E8590C', tileActive:'#8A8F99', tableHead:'#3B0B0B', rowAlt:'#FFE3E3', field:'#5A1010' },
    violet:  { name:'مۆری',  primary:'#6458FF', primary2:'#978FFF', primary3:'#423AAA', bg:'#E7E5FF', navy:'#1B2747', navy2:'#052747', slate:'#47455E', surface:'#FFFFFF', text:'#0F0F30', muted:'#47455E', line:'#D3D0F5' },
    ocean:   { name:'شینی دەریا',  primary:'#1E88E5', primary2:'#64B5F6', primary3:'#1565C0', bg:'#E3F2FD', navy:'#0D2B45', navy2:'#0A1F33', slate:'#37526B', surface:'#FFFFFF', text:'#0D1B2A', muted:'#45607A', line:'#C7DEF2' },
    emerald: { name:'سەوزی زمرد',  primary:'#10A37F', primary2:'#4CC9A6', primary3:'#0B7A5F', bg:'#E3F6EF', navy:'#0F2E26', navy2:'#0A211B', slate:'#365A50', surface:'#FFFFFF', text:'#0C231D', muted:'#3F6157', line:'#C3E8DB' },
    gold:    { name:'زێڕینی بۆن',  primary:'#B8860B', primary2:'#D9AE45', primary3:'#8A6408', bg:'#FAF4E6', navy:'#2B2117', navy2:'#1C150E', slate:'#5A4A36', surface:'#FFFFFF', text:'#2B2117', muted:'#6E5C45', line:'#EADFC6' },
    rose:    { name:'پەمەیی گوڵ',  primary:'#D63384', primary2:'#E879B0', primary3:'#A61E63', bg:'#FCE8F1', navy:'#3A1228', navy2:'#280B1B', slate:'#6A3A52', surface:'#FFFFFF', text:'#2E0D1F', muted:'#74475D', line:'#F2CDE0' },
    sunset:  { name:'پرتەقاڵی',    primary:'#F26B1D', primary2:'#F7A26B', primary3:'#C24F0C', bg:'#FFF0E6', navy:'#33190A', navy2:'#231006', slate:'#6B4430', surface:'#FFFFFF', text:'#2D1608', muted:'#7A5440', line:'#F5D6C2' },
    gray:    { name:'خۆڵەمێشی',    primary:'#4B5563', primary2:'#9CA3AF', primary3:'#1F2937', bg:'#F1F2F4', navy:'#111827', navy2:'#0B1120', slate:'#374151', surface:'#FFFFFF', text:'#111827', muted:'#4B5563', line:'#DDE0E5' },
    teal:    { name:'فەیرۆزی (PerfumePOS)', primary:'#0F766E', primary2:'#5EC4B8', primary3:'#0B5A54', bg:'#F4F6FA', navy:'#0F766E', navy2:'#0B5A54', slate:'#17202E', surface:'#FFFFFF', text:'#17202E', muted:'#6B7686', line:'#E3E8EF', accent:'#B45309', tableHead:'#0F766E', rowAlt:'#F0FBF9', field:'#9FB3C8' },
    tealdark:{ name:'فەیرۆزی تاریک', primary:'#2DD4BF', primary2:'#5EEAD4', primary3:'#14B8A6', bg:'#0E141B', navy:'#18212C', navy2:'#0E141B', slate:'#273241', surface:'#18212C', text:'#E8EDF3', muted:'#93A0B0', line:'#273241', accent:'#FBBF24', tableHead:'#12332F', rowAlt:'#141C26', field:'#3A4A5E' },
    dark:    { name:'تاریکی شەو',  primary:'#7C6CFF', primary2:'#A69BFF', primary3:'#5446D6', bg:'#151827', navy:'#0B0D17', navy2:'#070910', slate:'#2A2E45', surface:'#1F2337', text:'#E8E8F5', muted:'#A3A6C2', line:'#30354F' },
  };
/* 19 more colour sets made from one main colour (30 in total) */
(function () {
  const mk = (name, p, dark) => dark
    ? { name, primary:p, primary2:p, primary3:p, bg:'#111317', navy:'#1C1F26', navy2:'#111317', slate:'#2A2E37', surface:'#1C1F26', text:'#EEF0F4', muted:'#A0A6B2', line:'#343944', accent:p, tileActive:p, tableHead:'#2A2E37', rowAlt:'#20242C', field:p }
    : { name, primary:p, primary2:'color-mix(in srgb,' + p + ' 60%,#fff)', primary3:'color-mix(in srgb,' + p + ' 75%,#000)', bg:'color-mix(in srgb,' + p + ' 8%,#fff)', navy:'color-mix(in srgb,' + p + ' 70%,#000)', navy2:'color-mix(in srgb,' + p + ' 55%,#000)', slate:'color-mix(in srgb,' + p + ' 45%,#333)', surface:'#FFFFFF', text:'#14161B', muted:'#5B6070', line:'#DADDE3', accent:p, tileActive:p, tableHead:'color-mix(in srgb,' + p + ' 70%,#000)', rowAlt:'color-mix(in srgb,' + p + ' 10%,#fff)', field:'color-mix(in srgb,' + p + ' 70%,#000)' };
  Object.assign(THEMES, {
    black:mk('ڕەش','#222222'), white:Object.assign(mk('سپی','#6B7280'), { navy:'#F3F4F6', navy2:'#E5E7EB', bg:'#FFFFFF', tableHead:'#4B5563' }),
    red:mk('سوور','#D32F2F'), crimson:mk('سووری تاریک','#8B1E2D'), blue:mk('شین','#1D4ED8'), navyb:mk('شینی تاریک','#1E2A5A'),
    sky:mk('شینی ئاسمانی','#0EA5E9'), green:mk('سەوز','#16A34A'), olive:mk('زەیتوونی','#6B7A1F'), lime:mk('سەوزی کاڵ','#65A30D'),
    purple:mk('مۆری تاریک','#6D28D9'), lavender:mk('لاوەندەر','#8B7FD1'), pink:mk('پەمەیی','#EC4899'), orange:mk('پرتەقاڵی تۆخ','#EA580C'),
    brown:mk('قاوەیی','#7C4A2D'), coffee:mk('قاوە','#4B3621'), silver:mk('زیوی','#7A8794'), goldd:mk('زێڕینی تاریک','#C9A227', true), red_d:mk('سووری شەو','#E5484D', true)
  });
})();
/* 12 design styles */
const STYLES = { classic:'کلاسیک', soft:'نەرم', flat:'تەخت', card:'کارتی سپی', round:'خڕ', sharp:'تیژ', shadow:'سێبەردار', outline:'هێڵدار', gradient:'ڕەنگی تێکەڵ', glass:'شووشەیی', compact:'چڕ', bold:'ئەستوور' };
/* fonts that write Kurdish well (NRT is inside the program, the others come with Windows) */
const FONTS = { nrt:['NRT (بنەڕەتی)',"'NRT','NRT Reg',Tahoma,sans-serif"], tahoma:['Tahoma','Tahoma,sans-serif'], segoe:['Segoe UI',"'Segoe UI',Tahoma,sans-serif"], arial:['Arial','Arial,sans-serif'],
  times:['Times New Roman',"'Times New Roman',serif"], mss:['Microsoft Sans Serif',"'Microsoft Sans Serif',Tahoma,sans-serif"], sakkal:['Sakkal Majalla',"'Sakkal Majalla',Tahoma,serif"],
  trad:['Traditional Arabic',"'Traditional Arabic',serif"], simp:['Simplified Arabic',"'Simplified Arabic',Tahoma,serif"], uighur:['Microsoft Uighur',"'Microsoft Uighur',Tahoma,sans-serif"], courier:['Courier New',"'Courier New',monospace"] };
const SIZES = [0.85, 0.93, 1, 1.1, 1.2, 1.32];
const SIZEN = ['زۆر بچووک','بچووک','مامناوەند','گەورە','زۆر گەورە','زۆر زۆر گەورە'];
const DEFAULTS = { theme:'classic', style:'classic', fs:1, font:'nrt' };

function load() {
    try { const a = Object.assign({}, DEFAULTS, JSON.parse(localStorage.getItem('appearance') || '{}')); if (!SIZES.includes(+a.fs)) a.fs = 1; return a; }
    catch (e) { return Object.assign({}, DEFAULTS); }
  }
function store(a) { try { localStorage.setItem('appearance', JSON.stringify(a)); } catch (e) {} }

(function () { const st = document.createElement('style'); st.id = 'bs-styles'; st.textContent = `
  body.style-soft{--radius:14px} body.style-flat{--radius:0px} body.style-card{--radius:10px} body.style-round{--radius:22px} body.style-sharp{--radius:2px}
  body.style-shadow .btn,body.style-shadow .k,body.style-shadow .tile,body.style-shadow .prod,body.style-shadow .card{box-shadow:0 4px 12px rgba(0,0,0,.25)!important}
  body.style-outline .btn,body.style-outline .k,body.style-outline .tile,body.style-outline .card{outline:2px solid rgba(0,0,0,.35);outline-offset:-3px}
  body.style-gradient .btn,body.style-gradient .k,body.style-gradient .tile{background-image:linear-gradient(180deg,rgba(255,255,255,.28),rgba(0,0,0,.18))!important}
  body.style-glass .btn,body.style-glass .k,body.style-glass .tile,body.style-glass .card{opacity:.93;box-shadow:inset 0 1px 0 rgba(255,255,255,.5),0 2px 10px rgba(0,0,0,.15)!important}
  body.style-compact{--radius:4px} body.style-compact .btn,body.style-compact .k{letter-spacing:-.2px}
  body.style-bold .btn,body.style-bold .k,body.style-bold .tile,body.style-bold .lbl{font-weight:bold!important}`;
  (document.head || document.documentElement).appendChild(st); })();

/* font size: every text is scaled from its own size, also text drawn later (lists, dialogs) */
let FS = 1;
function scaleEl(el) { if (!(el instanceof HTMLElement) || el.closest('#bs-osk,#bs-bar')) return;
  if (el.dataset.bfs == null) { const v = parseFloat(getComputedStyle(el).fontSize); if (!v) return; el.dataset.bfs = v; }
  el.style.fontSize = FS === 1 ? '' : (el.dataset.bfs * FS) + 'px'; }
function scaleAll() { if (!document.body) return; document.body.querySelectorAll('*').forEach(e => { if (!/^(SCRIPT|STYLE|SVG|PATH|USE|SYMBOL|svg|path|use|symbol)$/.test(e.tagName)) scaleEl(e); }); }
let fsObs = null;
function watchFS() { if (fsObs || !document.body) return; fsObs = new MutationObserver(ms => { if (FS === 1) return; ms.forEach(m => m.addedNodes.forEach(n => { if (n.nodeType === 1) { scaleEl(n); n.querySelectorAll && n.querySelectorAll('*').forEach(scaleEl); } })); });
  fsObs.observe(document.body, { childList:true, subtree:true }); }

function applyVars(a) {
    const t = THEMES[a.theme] || THEMES.classic, r = document.documentElement.style;
    r.setProperty('--primary', t.primary);  r.setProperty('--primary-2', t.primary2); r.setProperty('--primary-3', t.primary3);
    r.setProperty('--bg', t.bg);            r.setProperty('--navy', t.navy);          r.setProperty('--navy-2', t.navy2);
    r.setProperty('--slate', t.slate);      r.setProperty('--surface', t.surface);    r.setProperty('--text', t.text);
    r.setProperty('--accent', t.accent || t.primary); r.setProperty('--tile-active', t.tileActive || t.primary);
    r.setProperty('--table-head', t.tableHead || t.navy); r.setProperty('--row-alt', t.rowAlt || 'color-mix(in srgb, ' + t.primary + ' 10%, #fff)'); r.setProperty('--field', t.field || t.navy);
    r.setProperty('--muted', t.muted);      r.setProperty('--line', t.line);          r.setProperty('--fs', 1);
  document.body.classList.remove(...Object.keys(STYLES).map(k => 'style-' + k));
  document.body.classList.add('style-' + (STYLES[a.style] ? a.style : 'classic'));
  let ff = document.getElementById('bs-font'); if (!ff) { ff = document.createElement('style'); ff.id = 'bs-font'; document.head.appendChild(ff); }
  const f = FONTS[a.font] || FONTS.nrt; ff.textContent = a.font && a.font !== 'nrt' ? `body,body *:not(.num):not(svg):not(svg *){font-family:${f[1]}!important}` : '';
  const fs = +a.fs || 1; if (fs !== FS || fs !== 1) { FS = fs; scaleAll(); } watchFS();
}

/* fit to this screen: 'fill' stretches every screen to the whole window (no empty edges); saved per computer */
function bsFitMode() { try { return localStorage.getItem('bs_fit') || 'fit'; } catch (e) { return 'fit'; } }
function bsFit(st, W, H) { const fill = bsFitMode() === 'fill' && !/login\.html/.test(location.pathname);
  const tb = st.querySelector('#titlebar,#top,.titlebar'); document.documentElement.classList.toggle('bs-fill', fill);
  if (!fill) { if (tb) tb.style.visibility = ''; return false; }
  const BAR = 28, th = tb && tb.offsetTop === 0 ? tb.offsetHeight : 0; if (tb) tb.style.visibility = 'hidden';   // the title text goes away; the screen moves up into its place
  const sx = innerWidth / W, sy = (innerHeight - BAR) / (H - th); st.style.transformOrigin = '0 0'; st.style.transform = 'scale(' + sx + ',' + sy + ')';
  st.style.left = '0px'; st.style.top = (BAR - th * sy) + 'px'; return true; }
function bsSetFit(m) { try { window.api && api.full && api.full(m === 'fill'); } catch (e) {} try { localStorage.setItem('bs_fit', m); localStorage.setItem('bs_fit_wh', screen.width + 'x' + screen.height); } catch (e) {} dispatchEvent(new Event('resize')); }

/* keep full screen on every start when the owner chose it */
try { if (bsFitMode() === 'fill' && window.api && api.full && !/login\.html/.test(location.pathname)) api.full(true); } catch (e) {}
