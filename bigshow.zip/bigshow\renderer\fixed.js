/* Fixed / recurring costs (خەرجییە جێگیرەکان)
   Every cost is spread over the days, so each day's report carries its fair share:
     weekly 100,000  -> 14,286 a day
     monthly 450,000 -> 450,000 / days in that month (15,000 in a 30-day month)
   The real payment (cash leaving the drawer) is a separate thing and is NOT counted twice.
   Works in the screens (window.Fixed) and in the program/bot (require). */
(function (root) {
  const PERIODS = { day:'ڕۆژانە', week:'هەفتانە', month:'مانگانە', year:'ساڵانە' };
  const TYPES = ['مووچە', 'کرێ', 'کارەبا / مۆلیدە', 'ئینتەرنێت', 'پاککردنەوە', 'تر'];
  const WEEKDAYS = ['یەکشەممە', 'دووشەممە', 'سێشەممە', 'چوارشەممە', 'پێنجشەممە', 'هەینی', 'شەممە'];   // JS getDay() order

  const DEFAULTS = [];

  const daysInMonth = d => new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate();
  const isLeap = y => (y % 4 === 0 && y % 100 !== 0) || y % 400 === 0;

  /* share of one cost on one calendar day */
  function shareOn(c, day) {
    if (!c.active || !(c.amount > 0)) return 0;
    if (c.from && day < new Date(c.from)) return 0;
    if (c.period === 'day')   return c.amount;
    if (c.period === 'week')  {                                   // with a day off: spread over the 6 working days
      if (c.offDay !== undefined && c.offDay !== null && c.offDay !== '') return day.getDay() === Number(c.offDay) ? 0 : c.amount / 6;
      return c.amount / 7;
    }
    if (c.period === 'month') return c.amount / daysInMonth(day);
    if (c.period === 'year')  return c.amount / (isLeap(day.getFullYear()) ? 366 : 365);
    return 0;
  }

  /* total (and per item) for a period [from, to)  – dates are local days */
  function forRange(list, from, to) {
    const items = list.map(c => ({ name:c.name, type:c.type, total:0 }));
    const d = new Date(from); d.setHours(12, 0, 0, 0);
    const end = new Date(to); end.setHours(12, 0, 0, 0);
    let days = 0;
    while (d < end) { list.forEach((c, i) => items[i].total += shareOn(c, d)); d.setDate(d.getDate() + 1); days++; }
    return { total:items.reduce((a, x) => a + x.total, 0), items:items.filter(x => x.total > 0), days };
  }

  /* payments that fall due on a day (for reminders / recording the cash payment) */
  function dueOn(list, day) {
    return list.filter(c => c.active && c.amount > 0 && (
      (c.period === 'day') ||
      (c.period === 'week'  && day.getDay() === Number(c.payDay)) ||
      (c.period === 'month' && day.getDate() === Math.min(Number(c.payDay) || 1, daysInMonth(day))) ||
      (c.period === 'year'  && day.getDate() === 1 && day.getMonth() === (Number(c.payDay) || 1) - 1)));
  }
  function upcoming(list, fromDay, n) {
    const out = [], d = new Date(fromDay); d.setHours(12, 0, 0, 0);
    for (let i = 0; i < n; i++) { dueOn(list, d).filter(c => c.period !== 'day').forEach(c => out.push({ date:new Date(d), c })); d.setDate(d.getDate() + 1); }
    return out;
  }
  const perDay   = (list, day) => list.reduce((a, c) => a + shareOn(c, day || new Date()), 0);
  const perMonth = (list, day) => { day = day || new Date(); const f = new Date(day.getFullYear(), day.getMonth(), 1), t = new Date(day.getFullYear(), day.getMonth() + 1, 1); return forRange(list, f, t).total; };

  /* storage for the screen preview (in the real program this comes from the database table fixed_costs) */
  function loadList() {
    try { const s = localStorage.getItem('fixedCosts2'); if (s) return JSON.parse(s); } catch (e) {}
    return DEFAULTS.map(x => Object.assign({}, x));
  }
  function saveList(list) { try { localStorage.setItem('fixedCosts2', JSON.stringify(list)); } catch (e) {} }

  const api = { PERIODS, TYPES, WEEKDAYS, DEFAULTS, shareOn, forRange, dueOn, upcoming, perDay, perMonth, loadList, saveList, daysInMonth };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.Fixed = api;
})(typeof window !== 'undefined' ? window : globalThis);
