﻿/* =====================================================================
   Bigshow POS — new database (bigshow_pos)
   Run once with:  npm run setup-db
   ===================================================================== */
USE bigshow_pos;
GO

/* ---------- settings & users ---------- */
CREATE TABLE settings (k NVARCHAR(50) PRIMARY KEY, v NVARCHAR(MAX));
CREATE TABLE users (
  id INT IDENTITY PRIMARY KEY, name NVARCHAR(60) NOT NULL UNIQUE,
  pass_hash NVARCHAR(200) NOT NULL, role NVARCHAR(20) NOT NULL DEFAULT 'cashier',  -- owner | cashier
  pin_hash NVARCHAR(200) NULL,                       -- owner PIN (17)
  active BIT NOT NULL DEFAULT 1, created_at DATETIME2 NOT NULL DEFAULT SYSDATETIME());

/* ---------- catalogue ---------- */
CREATE TABLE categories (id INT IDENTITY PRIMARY KEY, name NVARCHAR(80) NOT NULL, sort INT DEFAULT 0, visible BIT DEFAULT 1);
CREATE TABLE companies (id INT IDENTITY PRIMARY KEY, name NVARCHAR(120) NOT NULL, phone NVARCHAR(30), whatsapp NVARCHAR(30), address NVARCHAR(200),
  currency NVARCHAR(10) DEFAULT 'IQD', balance_iqd DECIMAL(18,2) DEFAULT 0, balance_usd DECIMAL(18,2) DEFAULT 0);
CREATE TABLE products (
  id INT IDENTITY PRIMARY KEY, code NVARCHAR(40), name NVARCHAR(150) NOT NULL,
  orig_brand NVARCHAR(150) NULL,                     -- (1) original brand it is inspired by
  family NVARCHAR(30) NULL, gender NVARCHAR(20) NULL, -- عود/شیرین/فرێش... پیاوان/ئافرەتان/هاوبەش
  category_id INT REFERENCES categories(id), company_id INT REFERENCES companies(id),
  qty INT NOT NULL DEFAULT 0, per_box INT NOT NULL DEFAULT 1,
  min_qty INT NOT NULL DEFAULT 2,                    -- (21) low-stock alert level
  tester_qty INT NOT NULL DEFAULT 0,                 -- (4) opened as tester
  cost DECIMAL(18,2) DEFAULT 0, cost_currency NVARCHAR(5) DEFAULT 'IQD', cost_usd DECIMAL(18,4) NULL,
  price DECIMAL(18,2) NOT NULL DEFAULT 0, price_box DECIMAL(18,2) DEFAULT 0,
  expire DATE NULL, photo VARBINARY(MAX) NULL, active BIT DEFAULT 1,
  created_at DATETIME2 DEFAULT SYSDATETIME(), old_id BIGINT NULL);
CREATE INDEX ix_products_name ON products(name);
CREATE TABLE barcodes (id INT IDENTITY PRIMARY KEY, product_id INT NOT NULL REFERENCES products(id), code NVARCHAR(60) NOT NULL UNIQUE, is_box BIT DEFAULT 0);
CREATE TABLE price_history (                         -- (24)
  id INT IDENTITY PRIMARY KEY, product_id INT REFERENCES products(id), at DATETIME2 DEFAULT SYSDATETIME(),
  company_id INT NULL, cost DECIMAL(18,4), currency NVARCHAR(5), usd_rate DECIMAL(18,2), cost_iqd DECIMAL(18,2), price DECIMAL(18,2), source NVARCHAR(20));
CREATE TABLE offers (                                -- (5) bundle offers
  id INT IDENTITY PRIMARY KEY, name NVARCHAR(150), category_id INT NULL, product_id INT NULL,
  qty INT NOT NULL, bundle_price DECIMAL(18,2) NOT NULL, from_date DATE NULL, to_date DATE NULL, active BIT DEFAULT 1);

/* ---------- customers (29, 30) ---------- */
CREATE TABLE customers (id INT IDENTITY PRIMARY KEY, phone NVARCHAR(20) UNIQUE, name NVARCHAR(80), note NVARCHAR(200), created_at DATETIME2 DEFAULT SYSDATETIME());

/* ---------- sales ---------- */
CREATE TABLE sales (
  id INT IDENTITY(1,1) PRIMARY KEY, invoice_no INT NOT NULL UNIQUE, at DATETIME2 NOT NULL DEFAULT SYSDATETIME(),
  user_id INT REFERENCES users(id), customer_id INT NULL REFERENCES customers(id),
  subtotal DECIMAL(18,2), discount DECIMAL(18,2) DEFAULT 0, offer_discount DECIMAL(18,2) DEFAULT 0, total DECIMAL(18,2),
  cost_total DECIMAL(18,2), profit DECIMAL(18,2), received DECIMAL(18,2), printed BIT DEFAULT 1, old_no NVARCHAR(30) NULL);
CREATE TABLE sale_items (id INT IDENTITY PRIMARY KEY, sale_id INT NOT NULL REFERENCES sales(id), product_id INT REFERENCES products(id),
  name NVARCHAR(150), qty INT, price DECIMAL(18,2), discount DECIMAL(18,2) DEFAULT 0, cost DECIMAL(18,2), profit DECIMAL(18,2));
CREATE TABLE held_receipts (id INT IDENTITY PRIMARY KEY, at DATETIME2 DEFAULT SYSDATETIME(), user_id INT, data NVARCHAR(MAX));   -- (9)
CREATE TABLE returns (id INT IDENTITY PRIMARY KEY, sale_id INT NULL REFERENCES sales(id), at DATETIME2 DEFAULT SYSDATETIME(), user_id INT,
  total DECIMAL(18,2), profit DECIMAL(18,2), reason NVARCHAR(200));
CREATE TABLE return_items (id INT IDENTITY PRIMARY KEY, return_id INT REFERENCES returns(id), product_id INT, name NVARCHAR(150), qty INT, price DECIMAL(18,2), profit DECIMAL(18,2));

/* ---------- purchases ---------- */
CREATE TABLE purchases (id INT IDENTITY PRIMARY KEY, company_id INT REFERENCES companies(id), invoice NVARCHAR(40), at DATETIME2 DEFAULT SYSDATETIME(),
  currency NVARCHAR(5), usd_rate DECIMAL(18,2), total DECIMAL(18,2), paid DECIMAL(18,2) DEFAULT 0, due_date DATE NULL, user_id INT, old_id BIGINT NULL);
CREATE TABLE purchase_items (id INT IDENTITY PRIMARY KEY, purchase_id INT REFERENCES purchases(id), product_id INT, qty INT, cost DECIMAL(18,4), price DECIMAL(18,2));
CREATE TABLE company_payments (id INT IDENTITY PRIMARY KEY, company_id INT REFERENCES companies(id), at DATETIME2 DEFAULT SYSDATETIME(), amount DECIMAL(18,2), currency NVARCHAR(5), note NVARCHAR(200), user_id INT);

/* ---------- money ---------- */
CREATE TABLE cash_moves (                            -- treasury (خەزێنە)
  id INT IDENTITY PRIMARY KEY, at DATETIME2 NOT NULL DEFAULT SYSDATETIME(), kind NVARCHAR(20) NOT NULL,  -- sale|return|out|in|expense|salary
  ref_id INT NULL, description NVARCHAR(300), amount_in DECIMAL(18,2) DEFAULT 0, amount_out DECIMAL(18,2) DEFAULT 0, user_id INT);
CREATE TABLE expenses (id INT IDENTITY PRIMARY KEY, at DATETIME2 DEFAULT SYSDATETIME(), type NVARCHAR(80), amount DECIMAL(18,2), note NVARCHAR(200), user_id INT);
CREATE TABLE salaries (id INT IDENTITY PRIMARY KEY, at DATETIME2 DEFAULT SYSDATETIME(), employee NVARCHAR(80), month NVARCHAR(20), amount DECIMAL(18,2), user_id INT);
CREATE TABLE damaged (id INT IDENTITY PRIMARY KEY, at DATETIME2 DEFAULT SYSDATETIME(), product_id INT, qty INT, cost DECIMAL(18,2), note NVARCHAR(200), user_id INT);
CREATE TABLE closings (                              -- (13, 14, 15)
  id INT IDENTITY PRIMARY KEY, at DATETIME2 DEFAULT SYSDATETIME(), user_id INT, invoices INT, items INT,
  sales DECIMAL(18,2), returns DECIMAL(18,2), expenses DECIMAL(18,2), fixed_costs DECIMAL(18,2), net_profit DECIMAL(18,2), taken DECIMAL(18,2), left_in_box DECIMAL(18,2));

/* ---------- fixed / recurring costs (rent, staff wage...) — spread over every day ---------- */
CREATE TABLE fixed_costs (id INT IDENTITY PRIMARY KEY, name NVARCHAR(100) NOT NULL, type NVARCHAR(40), amount DECIMAL(18,2) NOT NULL,
  period NVARCHAR(10) NOT NULL,          -- day | week | month | year
  pay_day INT NULL,                      -- weekday 0-6 (week) / day of month (month) / month (year)
  off_day INT NULL,                      -- weekly cost with a day off: spread over the 6 working days
  active BIT NOT NULL DEFAULT 1, from_date DATE NULL);
INSERT INTO fixed_costs(name, type, amount, period, pay_day, off_day) VALUES (N'کرێی کارمەند', N'مووچە', 120000, 'week', 1, 2), (N'کرێی دوکان', N'کرێ', 450000, 'month', 1, NULL);

GO
/* ---------- merged from PerfumePOS (the earlier app) ---------- */
CREATE TABLE brands (id INT IDENTITY PRIMARY KEY, name NVARCHAR(100) NOT NULL UNIQUE, country NVARCHAR(50) NULL, active BIT DEFAULT 1);
ALTER TABLE products ADD brand_id INT NULL REFERENCES brands(id), size_ml SMALLINT NULL, image_path NVARCHAR(300) NULL;
ALTER TABLE customers ADD birth_date DATE NULL, fav_scent NVARCHAR(200) NULL, is_vip BIT NOT NULL DEFAULT 0, points INT NOT NULL DEFAULT 0, active BIT NOT NULL DEFAULT 1;
ALTER TABLE sales ADD cancelled BIT NOT NULL DEFAULT 0, cancel_reason NVARCHAR(200) NULL, box_id INT NULL, pay_method NVARCHAR(20) NULL;
ALTER TABLE users ADD perms NVARCHAR(MAX) NULL;      -- JSON list of allowed screens for a cashier
/* customer debt (old debts + payments) */
CREATE TABLE customer_debts (id INT IDENTITY PRIMARY KEY, customer_id INT NOT NULL REFERENCES customers(id), at DATETIME2 DEFAULT SYSDATETIME(),
  amount DECIMAL(18,2) NOT NULL, kind NVARCHAR(10) NOT NULL, note NVARCHAR(200), user_id INT);        -- kind: debt | pay
/* company manual debt (not from a purchase invoice) */
CREATE TABLE company_debts (id INT IDENTITY PRIMARY KEY, company_id INT NOT NULL REFERENCES companies(id), at DATETIME2 DEFAULT SYSDATETIME(),
  amount DECIMAL(18,2) NOT NULL, currency NVARCHAR(5) DEFAULT 'IQD', note NVARCHAR(200), user_id INT);
/* purchase returns */
CREATE TABLE purchase_returns (id INT IDENTITY PRIMARY KEY, company_id INT REFERENCES companies(id), at DATETIME2 DEFAULT SYSDATETIME(),
  currency NVARCHAR(5) DEFAULT 'IQD', total DECIMAL(18,2), note NVARCHAR(200), user_id INT);
CREATE TABLE purchase_return_items (id INT IDENTITY PRIMARY KEY, return_id INT REFERENCES purchase_returns(id), product_id INT, qty INT, cost DECIMAL(18,4));
/* employees */
CREATE TABLE employees (id INT IDENTITY PRIMARY KEY, name NVARCHAR(80) NOT NULL, phone NVARCHAR(30), salary DECIMAL(18,2) DEFAULT 0,
  period NVARCHAR(10) DEFAULT 'week', active BIT DEFAULT 1);
ALTER TABLE salaries ADD employee_id INT NULL REFERENCES employees(id);
INSERT INTO employees(name, salary, period) VALUES (N'خەتاب', 120000, 'week');
/* several cash boxes (cash, FIB, ZainCash...) */
CREATE TABLE cash_boxes (id INT IDENTITY PRIMARY KEY, name NVARCHAR(60) NOT NULL, active BIT DEFAULT 1);
INSERT INTO cash_boxes(name) VALUES (N'قاسە (کاش)'), (N'FIB'), (N'زین کاش');
ALTER TABLE cash_moves ADD box_id INT NOT NULL DEFAULT 1;
/* perfume swap (exchange) = a return + a new sale, linked */
CREATE TABLE swaps (id INT IDENTITY PRIMARY KEY, at DATETIME2 DEFAULT SYSDATETIME(), return_id INT, sale_id INT, difference DECIMAL(18,2), user_id INT);
GO

/* ---------- audit (18) ---------- */
CREATE TABLE audit_log (id BIGINT IDENTITY PRIMARY KEY, at DATETIME2 DEFAULT SYSDATETIME(), user_id INT, user_name NVARCHAR(60),
  product_id INT NULL, target NVARCHAR(200), kind NVARCHAR(30), old_value NVARCHAR(100), new_value NVARCHAR(100), reason NVARCHAR(200));
GO

/* ---------- useful views ---------- */
CREATE VIEW v_low_stock AS                           -- (21)
SELECT p.id, p.name, c.name AS company, p.qty, p.min_qty,
       ISNULL((SELECT SUM(si.qty) FROM sale_items si JOIN sales s ON s.id = si.sale_id WHERE si.product_id = p.id AND s.at >= DATEADD(DAY,-30,SYSDATETIME())),0) AS sold30
FROM products p LEFT JOIN companies c ON c.id = p.company_id
WHERE p.active = 1 AND p.qty <= p.min_qty;
GO
CREATE VIEW v_dormant AS                             -- (27)
SELECT p.id, p.name, p.qty, DATEDIFF(DAY, ISNULL(MAX(s.at), p.created_at), SYSDATETIME()) AS days_idle
FROM products p LEFT JOIN sale_items si ON si.product_id = p.id LEFT JOIN sales s ON s.id = si.sale_id
WHERE p.active = 1 AND p.qty > 0
GROUP BY p.id, p.name, p.qty, p.created_at
HAVING DATEDIFF(DAY, ISNULL(MAX(s.at), p.created_at), SYSDATETIME()) >= 60;
GO

CREATE VIEW v_customer_balance AS
SELECT c.id, c.name, c.phone, c.is_vip, c.points,
       ISNULL(SUM(CASE WHEN d.kind = 'debt' THEN d.amount ELSE -d.amount END), 0) AS balance
FROM customers c LEFT JOIN customer_debts d ON d.customer_id = c.id
GROUP BY c.id, c.name, c.phone, c.is_vip, c.points;
GO
CREATE VIEW v_company_balance AS
SELECT co.id, co.name, co.phone,
  ISNULL((SELECT SUM(total - paid) FROM purchases WHERE company_id = co.id), 0)
 + ISNULL((SELECT SUM(amount) FROM company_debts WHERE company_id = co.id), 0)
 - ISNULL((SELECT SUM(amount) FROM company_payments WHERE company_id = co.id), 0)
 - ISNULL((SELECT SUM(total) FROM purchase_returns WHERE company_id = co.id), 0) AS balance
FROM companies co;
GO
CREATE VIEW v_box_balance AS
SELECT b.id, b.name, ISNULL(SUM(m.amount_in - m.amount_out), 0) AS balance
FROM cash_boxes b LEFT JOIN cash_moves m ON m.box_id = b.id WHERE b.active = 1 GROUP BY b.id, b.name;
GO

INSERT INTO categories(name, sort) VALUES (N'BONE COPY',1),(N'بۆن',2),(N'بۆنی ماستەر',3),(N'قاپیشی جلد',4),(N'معطر جسم',5);
INSERT INTO settings(k, v) VALUES ('usd_rate','1680'),('next_invoice','1'),('shop_name',N'دوکانەکەمان'),('owner_whatsapp','');
GO

/* app login (created by PerfumePOS setup) gets full rights on this database */
IF SUSER_ID('perfumepos_app') IS NOT NULL AND USER_ID('perfumepos_app') IS NULL CREATE USER perfumepos_app FOR LOGIN perfumepos_app;
IF USER_ID('perfumepos_app') IS NOT NULL ALTER ROLE db_owner ADD MEMBER perfumepos_app;
GO
/* first users – passwords are set by 3-bigshow-setup.bat ($(OWNERPW), $(CASHPW), $(OWNERPIN)) */
INSERT INTO users(name, pass_hash, role, pin_hash) VALUES
 (N'بەڕێوەبەر', LOWER(CONVERT(VARCHAR(64), HASHBYTES('SHA2_256', 'bigshow:' + '$(OWNERPW)'), 2)), 'owner', LOWER(CONVERT(VARCHAR(64), HASHBYTES('SHA2_256', 'bigshow:' + '$(OWNERPIN)'), 2))),
 (N'خەتاب',    LOWER(CONVERT(VARCHAR(64), HASHBYTES('SHA2_256', 'bigshow:' + '$(CASHPW)'), 2)), 'cashier', NULL);
GO
