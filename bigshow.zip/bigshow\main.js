/* POS — desktop program (Electron) */
const { app, BrowserWindow, ipcMain, shell } = require('electron');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const db = require('./src/db');
const backup = require('./src/backup');
const telegram = require('./src/telegram');
const store = require('./src/store');

const ROOT = app.isPackaged ? path.dirname(app.getPath('exe')) : __dirname;
const CONFIG = path.join(ROOT, 'config.json');
const LOG = path.join(ROOT, 'log.txt');
let dbReadyDone; const dbReady = new Promise(r => dbReadyDone = r); // renderer waits here until SQL is connected
const log = m => { try { fs.appendFileSync(LOG, new Date().toISOString() + '  ' + m + '\n'); } catch (e) {} };
process.on('uncaughtException', e => log('UNCAUGHT ' + (e && e.stack || e)));   // never show a crash box; write it to log.txt

if (!fs.existsSync(CONFIG)) fs.copyFileSync(path.join(__dirname, 'config.example.json'), CONFIG);
const cfg = JSON.parse(fs.readFileSync(CONFIG, 'utf8'));
const hash = s => crypto.createHash('sha256').update('bigshow:' + s).digest('hex');

let win, bot, user = null;

// only one copy of the program may run
if (!app.requestSingleInstanceLock()) app.exit(0);
// never let Windows put the program to sleep while it waits for SQL Server
app.commandLine.appendSwitch('disable-background-timer-throttling');
app.commandLine.appendSwitch('disable-renderer-backgrounding');
app.whenReady().then(() => { try { require('electron').powerSaveBlocker.start('prevent-app-suspension'); } catch (e) {} });
app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });

function createWindow() {
  // always fill the whole screen (except the taskbar) so nothing is cut off at the sides
  const { screen } = require('electron');
  const wa = screen.getPrimaryDisplay().workArea;
  win = new BrowserWindow({
    x: wa.x, y: wa.y, width: wa.width, height: wa.height, frame: false, backgroundColor: '#1B2747', show: false,
    resizable: false, movable: false, maximizable: false,
    icon: path.join(__dirname, 'renderer', 'img', 'logo.png'), webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, backgroundThrottling: false }
  });
  win.webContents.on('console-message', (...a) => { const e = a[0] || {}, lv = typeof a[1] === 'number' ? a[1] : e.level, msg = typeof a[2] === 'string' ? a[2] : e.message, ln = typeof a[3] === 'number' ? a[3] : e.lineNumber, src = a[4] || e.sourceId || '';
    log('renderer[' + lv + '] ' + msg + ' @' + String(src).split('/').pop() + ':' + ln); });
  win.webContents.on('did-finish-load', () => log('page loaded ' + win.webContents.getURL().split('/').pop()));
  win.webContents.setWindowOpenHandler(({ url }) => { if (/^https:\/\/(wa\.me|api\.whatsapp\.com|www\.google\.com\/search)/.test(url)) shell.openExternal(url); return { action:'deny' }; });
  win.loadFile(path.join(__dirname, 'renderer', 'login.html'));
  win.once('ready-to-show', () => { win.setBounds(wa); win.show(); });
  screen.on('display-metrics-changed', () => { if (win.isFullScreen()) return; const w = screen.getPrimaryDisplay().workArea; win.setBounds(w); });
}

app.whenReady().then(async () => {
  createWindow();
  try {
    // login made by PerfumePOS "1-setup-sql.bat"; database = bigshow_pos (made by "3-bigshow-setup.bat")
    const loginFile = path.join(app.getPath('appData'), 'PerfumePOS', 'config.json');
    const login = fs.existsSync(loginFile) ? JSON.parse(fs.readFileSync(loginFile, 'utf8').replace(/^\uFEFF/, '')) : {};
    // SQL Server can be slow to start after Windows boots: keep trying for about 2 minutes
    for (let k = 1; ; k++) { try { await db.connect(Object.assign({}, login, cfg.database || {}, { database: 'bigshow_pos' })); break; }
      catch (e) { log('database try ' + k + ': ' + e.message); if (k >= 12) throw e; await new Promise(r => setTimeout(r, 5000)); } }
    log('database connected');
    await store.init(db.getPool());
    dbReadyDone();
    if (store.hasCache()) store.refresh().catch(() => {});   // newest data from SQL Server, in the background
    // one-time picture import: a file img-import.json next to the program = [{id, v:dataURL}] → saved to the products, then renamed .done
    const IMP = path.join(ROOT, 'img-import.json');
    if (fs.existsSync(IMP)) (async () => { try { const L = JSON.parse(fs.readFileSync(IMP, 'utf8'));
      for (let i = 0; i < L.length; i += 20) await store.tx(L.slice(i, i + 20).map(x => ({ t:'img', id:String(x.id), v:x.v })));
      fs.renameSync(IMP, IMP + '.done'); log('images imported: ' + L.length); } catch (e) { log('image import ERR ' + e.message); } })();
    bot = telegram.create(cfg, db, log, makePdf);
    bot.start().catch(e => log('bot start ' + e.message));
    backup.schedule(db, cfg, bot, log);
  } catch (e) {
    log('database error ' + e.message);
    dbReadyDone();
    const { dialog } = require('electron');
    dialog.showErrorBox('POS', 'پەیوەندی بە داتابەیسەوە نەکرا:\n' + e.message + '\n\nسەرەتا 1-SETUP.bat بکەرەوە (Run as administrator).');
  }
});
/* A4 PDF for the Telegram bot (/a4 and /pdf): render HTML in a hidden window */
async function makePdf(html) { const w = new BrowserWindow({ show:false, webPreferences:{ javascript:false } });
  try { await w.loadURL('data:text/html;charset=utf-8,' + encodeURIComponent(html)); return await w.webContents.printToPDF({ pageSize:'A4', printBackground:true }); } finally { w.destroy(); } }
app.on('window-all-closed', () => app.quit());
app.on('before-quit', () => { try { store.flush(); } catch (e) {} });

/* ---------- bridge for the screens (see preload.js) ---------- */
/* the new data store (all screens) */
store.setup({ file: path.join(ROOT, 'cache.json'), log });
ipcMain.handle('store:load', async () => { log('store:load wait'); if (!store.hasCache()) await dbReady; const t = Date.now(); try { const r = await store.load(); log('store:load ok ' + (Date.now() - t) + 'ms, users ' + ((r.D && r.D.users) || []).length); return r; } catch (e) { log('store:load ERR ' + e.message); throw e; } });
ipcMain.handle('store:reload', async () => { log('store:reload (refresh button)');   // wait at most 8 s for fresh data; otherwise keep the copy
  try { await Promise.race([store.refresh(), new Promise((_, j) => setTimeout(() => j(new Error('slow')), 8000))]); return true; } catch (e) { return false; } });
ipcMain.handle('store:tx', async (e, ops) => { await dbReady; const t = Date.now(); log('store:tx ' + ops.length + ' ops: ' + ops.slice(0, 5).map(o => o.t + ':' + (o.c || o.k || o.id)).join(',')); try { const r = await store.tx(ops); log('store:tx ok ' + (Date.now() - t) + 'ms'); return r; } catch (err) { log('store:tx ERR ' + err.message); throw err; } });
ipcMain.handle('tg:send', async (e, text) => { if (!(bot && bot.ready && bot.ready())) return false; try { await bot.send(text); return true; } catch (err) { log('tg ' + err.message); return false; } });

/* 🆘 help: a question goes to the developer's own support bot (support.json); his Telegram reply comes back into the program */
const SUP = path.join(__dirname, 'support.json');
const supCfg = () => { try { return JSON.parse(fs.readFileSync(SUP, 'utf8')); } catch (e) { return {}; } };
const supUrl = m => { const s = supCfg(); if (!s.token) throw new Error('no-token'); return 'https://api.telegram.org/bot' + s.token + '/' + m; };
const supApi = async (m, body) => { const r = await fetch(supUrl(m), { method:'POST', headers:{ 'Content-Type':'application/json' }, body:JSON.stringify(body || {}) }); const j = await r.json(); if (!j.ok) throw new Error(j.description || 'tg'); return j.result; };
async function supChat() { const s = supCfg(); if (s.chat) return s.chat;             // first time: the developer sends /start to the bot, and that chat is kept
  const u = await supApi('getUpdates', {}); const m = u.map(x => x.message).find(m => m && m.chat && m.chat.type === 'private' && /^\/start/.test(m.text || ''));
  if (!m) return null; s.chat = m.chat.id; try { fs.writeFileSync(SUP, JSON.stringify(s, null, 2)); } catch (e) {} return s.chat; }
ipcMain.handle('help:send', async (e, q, who, voice) => { try { const chat = await supChat(); if (!chat) { log('help: no /start found for the support bot'); return { ok:false, why:'chat' }; }
    const t = '🆘 داوای یارمەتی\n🏪 ' + (who && who.shop || '-') + '\n👤 ' + (who && who.user || '-') + '\n💻 ' + require('os').hostname() + '\n\n❓ ' + (String(q || '').slice(0, 3000) || '🎤 ڤۆیس') + '\n\n↩️ بۆ وەڵام: Reply لەسەر ئەم نامەیە بکە';
    let m;
    if (voice && voice.length) { const fd = new FormData(); fd.append('chat_id', String(chat)); fd.append('caption', t.slice(0, 1000));
      let ogg = null; try { ogg = require('./src/ogg')(Buffer.from(voice)); } catch (x) { log('help ogg ' + x.message); }   // real voice message (plays on every phone)
      if (ogg) fd.append('voice', new Blob([ogg], { type:'audio/ogg' }), 'voice.ogg'); else fd.append('document', new Blob([Buffer.from(voice)], { type:'audio/webm' }), 'voice.webm');
      const r = await fetch(supUrl(ogg ? 'sendVoice' : 'sendDocument'), { method:'POST', body:fd }); const j = await r.json(); if (!j.ok) throw new Error(j.description || 'tg'); m = j.result; }
    else m = await supApi('sendMessage', { chat_id:chat, text:t });
    return { ok:true, id:m.message_id }; } catch (err) { log('help ' + err.message); return { ok:false, why:err.message }; } });
ipcMain.handle('help:replies', async (e, ids) => { try { const u = await supApi('getUpdates', { allowed_updates:['message'] });   // no offset: every shop can still read its own replies
    return u.map(x => x.message).filter(m => m && m.reply_to_message && (ids || []).includes(m.reply_to_message.message_id))
      .map(m => ({ to:m.reply_to_message.message_id, mid:m.message_id, text:m.text || m.caption || (m.voice || m.audio ? '🎤 وەڵامی ڤۆیس هاتووە (لە تەلێگرامی گەشەپێدەر)' : '📎'), t:m.date * 1000 })); } catch (err) { return []; } });
ipcMain.handle('sys:hash', (e, s) => hash(s));
/* 🖨 receipt: print straight to the thermal printer (80mm), no dialog */
ipcMain.handle('prn:rc', async (e, html) => { const w = new BrowserWindow({ show:false, width:272, height:900 });
  try { await w.loadURL('data:text/html;charset=utf-8,' + encodeURIComponent(html));
    /* 🖨️ any receipt printer: config.json "printer"/"paper" win if set; otherwise find a thermal printer by name, then the Windows default */
    const list = await w.webContents.getPrintersAsync();
    const VIRT = /pdf|xps|onenote|fax|anydesk|send to|microsoft print/i;
    const THERM = /xprinter|xp-?\d|pos|receipt|thermal|epson\s*tm|tm-?[tm]\d|bixolon|srp-|sewoo|rongta|rp\d|gprinter|gp-|zjiang|zj-|hprt|sunmi|citizen|ct-s|star\s*(tsp|sp)|tsp\d|munbyn|goojprt|58\s*mm|80\s*mm|\b58\b|\b80\b/i;
    const real = list.filter(x => !VIRT.test(x.name));
    const p = (cfg.printer && list.find(x => x.name === cfg.printer)) || real.find(x => THERM.test(x.name)) || list.find(x => x.isDefault && !VIRT.test(x.name)) || real[0] || list.find(x => x.isDefault) || list[0];
    const opt = p && p.options || {}, desc = ((p && (p.name + ' ' + (p.description || ''))) || '') + ' ' + (opt['printer-make-and-model'] || '');
    const mm = +cfg.paper || (/58\s*mm|\b58\b|zj-?58|xp-?58|pos-?58|gp-?58/i.test(desc) ? 58 : 80);   // paper width: 58 or 80 mm
    if (mm === 58) await w.webContents.executeJavaScript('document.body.style.zoom = "0.68"');          // shrink the 80 mm receipt to fit 58 mm paper
    const h = await w.webContents.executeJavaScript('Math.ceil(document.body.scrollHeight * (parseFloat(document.body.style.zoom) || 1))');
    await new Promise((res, rej) => w.webContents.print({ silent:true, printBackground:true, deviceName: p ? p.name : '', margins:{ marginType:'none' },
      pageSize:{ width: mm === 58 ? 48000 : 72000, height: Math.max(60000, Math.ceil((h + 30) * 25400 / 96)) } }, (ok, err) => ok ? res() : rej(new Error(err || 'print failed'))));
    log('print ok ' + (p && p.name) + ' ' + mm + 'mm h=' + h); return true;
  } catch (err) { log('print ERR ' + err.message); return false; } finally { setTimeout(() => { try { w.destroy(); } catch (x) {} }, 2000); } });
ipcMain.handle('win:min', () => win.minimize());
ipcMain.handle('win:full', (e, on) => { if (win && win.isFullScreen() !== !!on) win.setFullScreen(!!on); return true; });   // 🖥️ fill the whole screen (also over the taskbar)
ipcMain.handle('win:refocus', () => { if (win && !win.isDestroyed()) { win.blur(); win.focus(); win.webContents.focus(); } return true; });   // fix: typing stops after alert/confirm on Windows
ipcMain.handle('win:quit', () => app.quit());
ipcMain.handle('open:external', (e, url) => { if (/^https:\/\/(wa\.me\/|api\.whatsapp\.com\/|www\.google\.com\/search\?)/.test(url)) shell.openExternal(url); });
ipcMain.handle('config:shop', () => cfg.shop);

ipcMain.handle('auth:login', async (e, name, pass) => {
  user = await db.checkLogin(name, pass, hash);
  return user;
});
ipcMain.handle('auth:users', () => db.run(`SELECT name FROM users WHERE active = 1 ORDER BY id`));
ipcMain.handle('auth:checkPin', async (e, pin) => {           // (17) owner PIN for deletes / big discounts
  const r = await db.run(`SELECT COUNT(*) n FROM users WHERE role = 'owner' AND pin_hash = @h`, { h: hash(pin) });
  return r[0].n > 0;
});

ipcMain.handle('db:query', async (e, name, params) => {
  if (!db.QUERIES[name]) throw new Error('unknown query ' + name);
  return db.QUERIES[name](params || {});
});
ipcMain.handle('db:act', async (e, op, args) => {          // merged PerfumePOS actions (purchase, debts, salary...)
  if (!user) throw new Error('سەرەتا بچۆ ژوورەوە');
  if (!db.ACTS[op]) throw new Error('unknown action ' + op);
  if (user.role !== 'owner' && !db.CASHIER_ACTS.includes(op)) throw new Error('ئەم کارە تەنها بۆ بەڕێوەبەرە');
  const r = await db.ACTS[op](args || {}, user, hash);
  log('act ' + op + ' by ' + user.name);
  if (bot && bot.notify) bot.notify(op, args, user).catch(() => {});
  return r && r.ok ? r : { ok: true };
});
ipcMain.handle('auth:me', () => user);
ipcMain.handle('sale:save', (e, s) => db.saveSale(Object.assign(s, { userId: user && user.id })));
ipcMain.handle('stock:adjust', (e, changes) => db.adjustStock(changes, user || { id: null, name: '?' }));
ipcMain.handle('day:close', async (e, c) => {
  const r = await db.closeDay(Object.assign(c, { userId: user && user.id }));
  if (bot) bot.closingSummary(Object.assign(c, { userName: user ? user.name : '' })).catch(err => log('closing msg ' + err.message));
  return r;
});
ipcMain.handle('backup:now', async () => {
  try { return await backup.backupNow(db, cfg, bot); } catch (e) { log('backup ' + e.message); return { ok: false, error: e.message }; }
});

/* 🔄 automatic updates from GitHub: only the program screens are replaced (next start); data is never touched */
const UPD = 'https://raw.githubusercontent.com/bigshowgaming2001/pos-updates/main/';
function localVer() { try { return JSON.parse(fs.readFileSync(path.join(__dirname, 'version.json'), 'utf8')).v || 0; } catch (e) { return 0; } }
async function checkUpdate() {
  try {
    const { net } = require('electron');
    const r = await net.fetch(UPD + 'version.json?t=' + Date.now(), { cache: 'no-store' }); if (!r.ok) return;
    const info = await r.json(); if (!(info.v > localVer())) return;
    const base = path.dirname(__dirname), dest = path.join(base, 'update.zip');
    if (fs.existsSync(dest)) return;   // already downloaded, waiting for the next start
    const z = await net.fetch(UPD + 'bigshow.zip?t=' + Date.now(), { cache: 'no-store' }); if (!z.ok) return;
    const buf = Buffer.from(await z.arrayBuffer());
    if (crypto.createHash('sha256').update(buf).digest('hex') !== String(info.sha256).toLowerCase()) { log('update: checksum mismatch, ignored'); return; }
    fs.writeFileSync(dest + '.tmp', buf); fs.renameSync(dest + '.tmp', dest);
    log('update: v' + info.v + ' downloaded, installs at next start');
  } catch (e) { log('update check: ' + e.message); }
}
app.whenReady().then(() => {
  setTimeout(checkUpdate, 20000); setInterval(checkUpdate, 3 * 3600 * 1000);
  const note = path.join(path.dirname(__dirname), 'updated.txt');
  if (fs.existsSync(note)) { try { fs.unlinkSync(note); } catch (e) {}
    setTimeout(() => { try { require('electron').dialog.showMessageBox(win, { type:'info', title:'POS', message:'✅ پرۆگرامەکە نوێکرایەوە بۆ دوایین وەشان.\nهەموو داتاکانت وەک خۆیان ماون.' }); } catch (e) {} }, 5000); }
});
