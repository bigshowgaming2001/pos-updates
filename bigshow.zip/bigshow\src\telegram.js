/* Built-in Telegram bot (owner only).
   - every action in the program is sent live (from the screens via 'tg:send')
   - daily summary at 16:30, commands: /roj /furosh /bokhcha /kam /mang /help */
const store = require('./store');
global.window = global.window || {};
require('../renderer/core.js');
const C = global.window.C;

function create(cfg, db, log, pdf) {
  const T = cfg.telegram || {}, API = 'https://api.telegram.org/bot' + T.token;
  const ready = () => !!(T.token && T.chatId);
  const KB = { keyboard:[['📊 ڕاپۆرتی ئەمڕۆ','📆 ڕاپۆرتی دوێنێ'],['💵 قازانجەکان','💰 خەزێنە'],['🧾 فرۆشراوەکانی ئەمڕۆ','📦 بۆنە فرۆشراوەکان'],['🗓 ئەم هەفتەیە','📅 ئەم مانگە'],['⏪ مانگی ڕابردوو','📈 ئەم ساڵ'],['🏆 زۆرترین فرۆشراو','🚫 مادە تەواوبووەکانی ئەمڕۆ'],['🚫 بۆنە تەواوبووەکان'],['🛒 کڕینی ئەمڕۆ','📝 خەرجییەکانی ئەمڕۆ'],['📄 ڕاپۆرت بە PDF','❓ یارمەتی']], resize_keyboard:true, is_persistent:true };
  async function send(text, kb) { if (!ready()) return; for (let i = 0; i < text.length; i += 3900)
    await fetch(API + '/sendMessage', { method:'POST', headers:{ 'Content-Type':'application/json' }, body:JSON.stringify(Object.assign({ chat_id:T.chatId, text:text.slice(i, i + 3900) }, kb ? { reply_markup:KB } : {})) }); }
  async function sendDocument(file, caption) { if (!ready()) return; const fs = require('fs'), fd = new FormData();
    fd.append('chat_id', T.chatId); fd.append('caption', caption || ''); fd.append('document', new Blob([fs.readFileSync(file)]), require('path').basename(file));
    await fetch(API + '/sendDocument', { method:'POST', body:fd }); }
  async function data() { const r = await store.load(); r.D.set = r.D.$set; delete r.D.$set; C.use(r.D); return C; }
  async function answer(cmd) { const c = await data(), D = c.D, n0 = c.n0;
    if (cmd === '/start') return '👋 سڵاو، بەخێربێیت بۆ بۆتی ' + D.set.shop.n + '\n\nهەموو داواکارییەکان لە دوگمەکانی خوارەوە ئامادەن، تەنها دوگمەیەک دابگرە:\n📊 ڕاپۆرتی ئەمڕۆ · 💵 قازانجەکان · 💰 خەزێنە\n🧾 فرۆشراوەکان · 🚫 بۆنە تەواوبووەکان · 📄 PDF\n\nیان بەروارێک بنووسە، وەک 20/11، بۆ ڕاپۆرتی ئەو ڕۆژە.';
    if (cmd === '/roj' || cmd === '/today') return c.dayTxt(new Date());
    if (cmd === '/qazanj') { const t = new Date(), y = t.getFullYear(), mo = t.getMonth(), R = [['ئەمڕۆ', c.d0(t)], ['ئەم هەفتەیە', c.addD(c.d0(t), -((t.getDay() + 1) % 7))], ['ئەم مانگە', new Date(y, mo, 1)], ['ئەم ساڵ', new Date(y, 0, 1)]];
      return '💵 قازانجەکان\n' + R.map(([l, f]) => { const o = c.stats(f, t); return `\n▫️ ${l}\n   فرۆشتن: ${n0(o.sales)}\n   قازانج: ${n0(o.profit)}\n   خەرجی و مووچە: ${n0(o.xs + o.fixed)}\n   ✅ قازانجی پاک: ${n0(o.net)}`; }).join('\n'); }
    if (cmd === '/xerji') { const t0 = c.today(), L = [...D.exp.filter(x => x.t >= t0).map(x => ({ t:x.t, l:x.cat + (x.note ? ' — ' + x.note : ''), a:x.amt })), ...D.sal.filter(x => x.t >= t0).map(x => ({ t:x.t, l:'مووچەی ' + x.emp, a:x.amt }))].sort((a, b) => a.t - b.t);
      return '📝 خەرجییەکانی ئەمڕۆ\n' + (L.map(x => `• ${c.hm(x.t)} ${x.l}: ${n0(x.a)}`).join('\n') || 'هیچ خەرجییەک نییە') + '\n━━━━\nکۆ: ' + n0(c.sa(L, x => x.a)); }
    if (cmd === '/zor') { const t = new Date(), f = +new Date(t.getFullYear(), t.getMonth(), 1), m2 = {}; D.sales.filter(s => s.t >= f).forEach(s => s.items.forEach(i => { const x = m2[i.n] = m2[i.n] || { q:0, v:0 }; x.q += i.q; x.v += i.p * i.q; }));
      const L = Object.entries(m2).sort((a, b) => b[1].q - a[1].q); return '🏆 زۆرترین فرۆشراوی ئەم مانگە\n' + (L.slice(0, 15).map(([k, x], i) => `${i + 1}. ${k} — ${x.q} دانە (${n0(x.v)})`).join('\n') || 'هیچ نییە') + (L.length > 15 ? '\n\n🔻 کەمترین فرۆشراو:\n' + L.slice(-5).reverse().map(([k, x]) => `• ${k} — ${x.q} دانە`).join('\n') : ''); }
    if (cmd === '/duene' || cmd === '/yesterday') return c.dayTxt(c.addD(new Date(), -1));
    if (cmd === '/furosh') { const t0 = c.today(), S = D.sales.filter(s => s.t >= t0); return '🧾 فرۆشتنی ئەمڕۆ (' + S.length + ')\n' + (S.map(s => c.hm(s.t) + ' #' + s.no + ' — ' + n0(s.tot) + (s.nr ? ' (بێ پسوڵە)' : '')).join('\n') || 'هیچ نییە') + '\n\n💵 کۆ: ' + n0(c.sa(S, s => s.tot)); }
    if (cmd === '/bokhcha' || cmd === '/xazena') return '💰 خەزێنەکان\n' + D.boxes.map(b => '• ' + b.n + ': ' + n0(c.bal(b.id))).join('\n') + '\n━━━━\nکۆ: ' + n0(c.bal());
    if (cmd === '/kam') return c.outTxt();
    if (cmd === '/tewaw') return c.outTxt(true);
    const t = new Date(), y = t.getFullYear(), mo = t.getMonth();
    const P = { '/mang':['📅 ئەم مانگە', new Date(y, mo, 1), t], '/month':['📅 ئەم مانگە', new Date(y, mo, 1), t], '/hefte':['🗓 ئەم هەفتەیە', c.addD(c.d0(t), -((t.getDay() + 1) % 7)), t],
      '/pesho':['⏪ مانگی ڕابردوو', new Date(y, mo - 1, 1), new Date(y, mo, 0)], '/sal':['📈 ئەم ساڵ', new Date(y, 0, 1), t] };
    let m = cmd.match(/^(\d{1,2})[\/\-.](\d{1,2})(?:[\/\-.](\d{2,4}))?$/) || cmd.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
    if (m) { const d = m[1].length === 4 ? new Date(+m[1], +m[2] - 1, +m[3]) : new Date(m[3] ? (+m[3] < 100 ? 2000 + +m[3] : +m[3]) : y, +m[2] - 1, +m[1]); return c.dayTxt(d); }
    if (P[cmd]) { const [lb, f, e] = P[cmd], o = c.stats(f, e);
      return `${lb} (${c.fd(f)} — ${c.fd(e)})\n💵 فرۆشتن: ${n0(o.sales)}\n📦 تێچووی مادەکان: ${n0(o.cost)}\n🏷️ داشکاندن: ${n0(o.ds)}\n↩️ گەڕانەوە: ${n0(o.ret)}\n📈 قازانج: ${n0(o.profit)}\n📝 خەرجی و مووچە: ${n0(o.xs)}\n📌 خەرجی جێگیر: ${n0(o.fixed)}\n✅ قازانجی پاک: ${n0(o.net)}\n🧾 پسوڵە: ${o.n}`; }
    if (cmd === '/kala') { const t0 = c.today(), m2 = {}; D.sales.filter(s => s.t >= t0).forEach(s => s.items.forEach(i => { const x = m2[i.n] = m2[i.n] || { q:0, v:0, p:0 }; x.q += i.q; x.v += i.p * i.q; x.p += (i.p - (i.c || 0)) * i.q; }));
      const L = Object.entries(m2).sort((a, b) => b[1].v - a[1].v); return '📦 کاڵا فرۆشراوەکانی ئەمڕۆ\n' + (L.map(([k, x]) => `• ${k} ×${x.q} = ${n0(x.v)} (قازانج ${n0(x.p)})`).join('\n') || 'هیچ نییە'); }
    if (cmd === '/krin') { const t0 = c.today(), L = D.pur.filter(p => p.t >= t0); return '🛒 کڕینی ئەمڕۆ\n' + (L.map(p => `• ${c.hm(p.t)} ${c.coN(p.co)}: ${n0(p.tot)} (${p.py === 'debt' ? 'قەرز' : 'کاش'})${p.ret ? ' — گەڕانەوە' : ''}\n  ${p.items.map(i => i.n + ' ×' + i.q).join('، ')}`).join('\n') || 'هیچ نییە'); }
    return 'ℹ️ دوگمەکانی خوارەوە دابگرە، یان ئەم فەرمانانە بنووسە:\n/qazanj — قازانجەکان\n/xerji — خەرجییەکانی ئەمڕۆ\n/zor — زۆرترین فرۆشراو\n/roj — کورتەی ئەمڕۆ\n/duene — دوێنێ\n/hefte — ئەم هەفتەیە\n/mang — ئەم مانگە\n/pesho — مانگی ڕابردوو\n/sal — ئەم ساڵ\n/furosh — فرۆشتنەکانی ئەمڕۆ\n/kala — کاڵا فرۆشراوەکان و قازانجیان\n/krin — کڕینی ئەمڕۆ\n/bokhcha — پارەی خەزێنەکان\n/kam — بۆنە تەواوبووەکان و نرخی کڕینی پێشوو\n/a4 120 — پسوڵەی ژمارە 120 بە PDF ی A4\n/pdf — ڕاپۆرتی ئەمڕۆ بە PDF ی A4 (یان /pdf 20/11)\nیان بەروارێک بنووسە، وەک: 20/11'; }
  const esc = x => String(x == null ? '' : x).replace(/[&<>"]/g, ch => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;' }[ch]));
  const page = (title, body) => `<html dir="rtl"><head><meta charset="utf-8"><style>@page{size:A4;margin:14mm}body{font-family:Tahoma,Arial;font-size:13px}h2{text-align:center;margin:0 0 4px}table{width:100%;border-collapse:collapse;margin-top:10px}td,th{border:1px solid #999;padding:6px}th{background:#eee}.c{text-align:center}pre{white-space:pre-wrap;font-family:Tahoma,Arial;font-size:13px}</style></head><body>${body}</body></html>`;
  function a4Receipt(c, s) { const sh = c.D.set.shop, sub = c.sa(s.items, i => i.p * i.q);
    return page('', `<h2>${esc(sh.n)}</h2><div class="c">${esc(sh.hd || '')}<br>${esc(sh.ph || '')} · ${esc(sh.addr || '')}</div><hr>
      <div>پسوڵە: <b>#${s.no}</b> · ${c.fTT(s.t)} · کاشێر: ${esc(s.u || '')}${s.emp ? ' · فرۆشیار: ' + esc(s.emp) : ''}${s.cu ? ' · کڕیار: ' + esc(s.cu) : ''}</div>
      <table><tr><th>#</th><th>بۆن</th><th>بڕ</th><th>نرخ</th><th>کۆ</th></tr>${s.items.map((i, k) => `<tr><td>${k + 1}</td><td>${esc(i.n)}${i.ts ? ' (تێستەر)' : ''}${i.gift ? ' (دیاری)' : ''}</td><td>${i.q}</td><td>${c.n0(i.p)}</td><td>${c.n0(i.p * i.q)}</td></tr>`).join('')}</table>
      <table><tr><td>کۆ</td><td>${c.n0(s.tot + (s.ds || 0))}</td></tr>${s.ds ? `<tr><td>داشکاندن</td><td>−${c.n0(s.ds)}</td></tr>` : ''}<tr><th>کۆی گشتی</th><th>${c.n0(s.tot)}</th></tr></table>
      ${s.note ? `<p>تێبینی: ${esc(s.note)}</p>` : ''}<p class="c">${esc(sh.note || '')}<br><b>${esc(sh.th || '')}</b></p>`); }
  async function pdfCmd(txt) { if (!pdf) return 'PDF لەم ئامێرەدا ئامادە نییە';
    const c = await data(), parts = c.nd(txt).trim().split(/\s+/), cmd = parts[0].toLowerCase(), arg = parts[1] || '', fs = require('fs'), os = require('os'), path = require('path');
    let html, name;
    if (cmd === '/a4') { const s = c.D.sales.filter(x => String(x.no) === arg.replace('#', '')).pop(); if (!s) return 'پسوڵەی ژمارە ' + arg + ' نەدۆزرایەوە. نموونە: /a4 120';
      html = a4Receipt(c, s); name = 'receipt-' + s.no + '.pdf'; }
    else { let d = new Date(); const m = arg.match(/^(\d{1,2})[\/\-.](\d{1,2})(?:[\/\-.](\d{2,4}))?$/); if (m) d = new Date(m[3] ? (+m[3] < 100 ? 2000 + +m[3] : +m[3]) : d.getFullYear(), +m[2] - 1, +m[1]);
      html = page('', `<pre>${esc(c.dayTxt(d))}\n\n${esc(c.outTxt())}</pre>`); name = 'report-' + c.iso(d) + '.pdf'; }
    const file = path.join(os.tmpdir(), name); fs.writeFileSync(file, await pdf(html)); await sendDocument(file, name); try { fs.unlinkSync(file); } catch (e) {} return null; }
  const BTN = { '📊 ڕاپۆرتی ئەمڕۆ':'/roj', '📆 ڕاپۆرتی دوێنێ':'/duene', '💵 قازانجەکان':'/qazanj', '💰 خەزێنە':'/bokhcha', '🧾 فرۆشراوەکانی ئەمڕۆ':'/furosh', '📦 بۆنە فرۆشراوەکان':'/kala', '🗓 ئەم هەفتەیە':'/hefte', '📅 ئەم مانگە':'/mang', '⏪ مانگی ڕابردوو':'/pesho', '📈 ئەم ساڵ':'/sal', '🏆 زۆرترین فرۆشراو':'/zor', '🚫 بۆنە تەواوبووەکان':'/kam', '🚫 مادە تەواوبووەکانی ئەمڕۆ':'/tewaw', '🛒 کڕینی ئەمڕۆ':'/krin', '📝 خەرجییەکانی ئەمڕۆ':'/xerji', '📄 ڕاپۆرت بە PDF':'/pdf', '❓ یارمەتی':'/help',
    '📊 ئەمڕۆ':'/roj', '📆 دوێنێ':'/duene', '📦 کاڵاکانی ئەمڕۆ':'/kala', '🚫 کاڵای کەم':'/kam' };
  let offset = 0, lastDaily = '';
  async function poll() { try { const r = await (await fetch(API + '/getUpdates?timeout=0&offset=' + offset)).json();
      for (const u of r.result || []) { offset = u.update_id + 1; const m = u.message; if (!m || String(m.chat.id) !== String(T.chatId)) continue;
        const txt0 = String(m.text || '').trim(), txt = BTN[txt0] === '/pdf' ? '/pdf' : txt0; if (/^\/(a4|pdf)\b/i.test(C.nd(txt))) { const r = await pdfCmd(txt).catch(e => 'هەڵە: ' + e.message); if (r) await send(r, true); continue; } await send(await answer(BTN[txt] || C.nd(txt).split(/[\s@]/)[0].toLowerCase()), true); } } catch (e) { log('tg poll ' + e.message); } }
  async function start() { if (!ready()) { log('telegram: no token/chatId in config.json'); return; }
    const CMDS = [['roj','📊 ڕاپۆرتی ئەمڕۆ'],['duene','📆 ڕاپۆرتی دوێنێ'],['qazanj','💵 قازانجەکان'],['bokhcha','💰 پارەی خەزێنەکان'],['furosh','🧾 فرۆشراوەکانی ئەمڕۆ'],['kala','📦 بۆنە فرۆشراوەکان و قازانجیان'],['hefte','🗓 ڕاپۆرتی ئەم هەفتەیە'],['mang','📅 ڕاپۆرتی ئەم مانگە'],['pesho','⏪ ڕاپۆرتی مانگی ڕابردوو'],['sal','📈 ڕاپۆرتی ئەم ساڵ'],['zor','🏆 زۆرترین و کەمترین فرۆشراو'],['tewaw','🚫 مادە تەواوبووەکانی ئەمڕۆ'],['kam','🚫 هەموو بۆنە تەواوبووەکان و نرخی کڕینیان'],['krin','🛒 کڕینی ئەمڕۆ'],['xerji','📝 خەرجییەکانی ئەمڕۆ'],['pdf','📄 ڕاپۆرتی ئەمڕۆ بە PDF'],['a4','🧾 پسوڵە بە PDF — نموونە: /a4 120'],['help','❓ یارمەتی']];
    fetch(API + '/setMyCommands', { method:'POST', headers:{ 'Content-Type':'application/json' }, body:JSON.stringify({ commands:CMDS.map(([command, description]) => ({ command, description })) }) }).catch(e => log('tg cmds ' + e.message));
    setInterval(poll, 4000);
    setInterval(async () => { const now = new Date(), day = now.toDateString();
      if (now.toTimeString().slice(0, 5) >= (T.dailyReportTime || '16:30') && lastDaily !== day) { lastDaily = day; try { const c = await data(); await send(c.dayTxt(now)); await send(c.outTxt(true)); } catch (e) { log('daily ' + e.message); } } }, 30000); }
  async function closingSummary() { return (await data()).dayTxt(new Date()); }
  return { start, send, sendDocument, ready, closingSummary, report: answer, notify: async () => {} };
}
module.exports = { create };
