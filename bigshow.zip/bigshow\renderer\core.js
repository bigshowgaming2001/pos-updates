/* Bigshow core — the data + rules shared by every screen.
   Rules come from the owner's 54 answers (docs/requirements-ku.md) and the tested
   web version (docs/wesani-taqikirdnewe-pos.html). Data lives in SQL Server (bs_doc). */
(function () {
const API = window.api && window.api.storeLoad ? window.api : null;
const COLS = ['products','sales','cos','pur','cpay','cdebt','cash','exp','sal','rets','sret','offers','users','cust','hold','adj','close','log','cats','emps','boxes','ecats','fixed'];
const DEFSET = { rate:1680, rno:0, own:'', sbox:1, shop:{ n:'', en:'', ph:'', addr:'', wa:1, vb:1, call:1, note:'سوپاس بۆ سەردانتان' } };
const SEED = {
  boxes:[{ id:1, n:'قاسەی دوکان' }],
  ecats:['کرێی دوکان','کارەبا','مۆلیدە','ئاو','ئینتەرنێت','پاککردنەوە','گواستنەوە','چاککردنەوە','شتی تر'].map((n, i) => ({ id:i + 1, n })),
  cats:['BONE COPY','بۆن','بۆنی ماستەر','قاپیشی جلد','معطر جسم'].map((n, i) => ({ id:i + 1, n })),
  emps:[],
  fixed:[{ id:1, name:'کرێی کارمەند', type:'مووچە', amount:120000, period:'week', payDay:1, offDay:2, active:true },
         { id:2, name:'کرێی دوکان', type:'کرێ', amount:450000, period:'month', payDay:1, active:true }]
};
const DPM = [];       // a new cashier gets NO rights until the owner ticks them
/* every right the owner can give (screens + buttons). Nothing is given automatically. */
const PERMS = [
  ['فرۆشتن', [['pos','🧾 فرۆشتن'],['nr','🗒️ فرۆشتن بێ پسوڵە'],['hold','⏸ هەڵپەساردنی پسوڵە'],['disc','🏷️ داشکاندن'],['gift','🎁 دیاری'],['price','💲 گۆڕینی نرخ لە سەبەتە'],['cdel','🗑️ سڕینەوە لە سەبەتە'],['sret','↩️ گەڕاندنەوەی فرۆشتن'],['swap','🔄 گۆڕینەوەی بۆن'],['cust','⭐ کڕیاران']]],
  ['مادە و کۆگا', [['prods','📦 تۆمار و دەستکاریی بۆن'],['pdel','🗑️ سڕینەوەی بۆن'],['stock','📋 زانیاری کۆگا'],['count','📦 جەردی خێرا بە بارکۆد'],['bulk','✏️ گۆڕینی بڕ و نرخ'],['cats','📂 جۆری مادە'],['out','🚫 مادە تەواوبووەکان'],['offers','🏷️ ئۆفەر'],['bar','🔢 بارکۆد'],['dmg','💔 مادەی خراپبوو']]],
  ['کڕین و جوملە', [['buy','🛒 کڕینی مادە'],['bret','📤 گەڕانەوەی کڕین'],['whl','📒 زانیاری جوملە و قەرز'],['cpay','🤝 پارەدانەوەی قەرز']]],
  ['پارە', [['box','💰 خەزێنە'],['close','🔒 داخستنی سندوق'],['exp','📝 خەرجی'],['fixed','📌 خەرجیی ڕۆژانەی خۆکار'],['sal','👷 مووچە'],['rate','💱 نرخی دۆلار']]],
  ['ڕاپۆرت', [['today','📅 ڕاپۆرتی ئەمڕۆ'],['rep','📊 ڕاپۆرتی گشتی و قازانج'],['log','📜 تۆماری کارەکان']]],
  ['سیستەم', [['set','⚙️ ڕێکخستنی دوکان و پسوڵە'],['theme','🎨 ڕووکار و دیزاین'],['users','👤 بەکارهێنەران و دەسەڵات'],['bak','🗄️ باکئەپ'],['undo','↩️ گەڕانەوەی هەنگاوی پێشوو']]]];
const PK = { hist:'buy', noimg:'prods', sug:'buy', hours:'rep', cos:'whl', stmt:'whl', debt:'whl', expired:'out' };       // old screen names → right
let UNDO = [], LBL = [], UNDOING = false;
const LOGOBW = '';   // shop logo in black & white for the 80mm receipt printer
let D = {}, IMG = {}, SNAP = {}, SNAPIMG = {}, U = null;

/* ---------- small helpers ---------- */
const nd = s => String(s == null ? '' : s).replace(/[٠-٩]/g, d => d.charCodeAt(0) - 1632).replace(/[۰-۹]/g, d => d.charCodeAt(0) - 1776);
const E = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[c]));
const n0 = n => Math.round(n || 0).toLocaleString('en-US');
const N = n => n0(n) + ' د.ع';
const p2 = n => String(n).padStart(2, '0');
const fd = d => p2(d.getDate()) + '/' + p2(d.getMonth() + 1) + '/' + d.getFullYear();
const fT = t => fd(new Date(t));
const fTT = t => { const d = new Date(t); return fd(d) + ' ' + p2(d.getHours()) + ':' + p2(d.getMinutes()); };
const hm = t => { const d = new Date(t); return p2(d.getHours()) + ':' + p2(d.getMinutes()); };
const d0 = d => { const x = new Date(d); x.setHours(0, 0, 0, 0); return x; };
const today = () => +d0(new Date());
const iso = d => d.getFullYear() + '-' + p2(d.getMonth() + 1) + '-' + p2(d.getDate());
const fromIso = s => { const a = String(s || '').split('-').map(Number); return a.length === 3 && a[0] ? new Date(a[0], a[1] - 1, a[2]) : null; };
const addD = (d, n) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };
const sa = (A, f) => (A || []).reduce((a, x) => a + f(x), 0);
const sm = (L, f) => (L || []).reduce((a, i) => a + i[f] * i.q, 0);
const uid = () => Date.now() * 1000 + Math.floor(Math.random() * 1000);
/* regular-customer level by number of visits (purchases): 1–2 silver, 3–4 gold, 5–9 diamond, 10–19 crown, 20+ platinum */
const TIERS = [[20,'🏆','پلاتین'],[10,'👑','تاج'],[5,'💎','ئەڵماس'],[3,'🥇','زێڕ'],[1,'🥈','زیو'],[0,'🆕','نوێ']];
const tier = n => { const t = TIERS.find(x => n >= x[0]); return { i:t[1], n:t[2] }; };
function custSales(id) { return D.sales.filter(s => s.cid === id && !s.ret).sort((a, b) => b.t - a.t); }
function custInfo(c) { const S = custSales(c.id), v = S.length; return { c, S, v, tier:tier(v), spent:sa(S, s => s.tot), last:S[0] ? S[0].t : 0 }; }
/* search: name starts with / contains the text (PTS → all PTS…), or the digits appear anywhere in the phone number */
function custFind(q, max) { q = nd(String(q || '')).trim().toLowerCase(); if (!q) return [];
  const dg = q.replace(/\D/g, ''), R = [];
  D.cust.forEach(c => { const n = nd(c.n || '').toLowerCase(), ph = nd(c.ph || '').replace(/\D/g, ''); let sc = 0;
    if (n.startsWith(q)) sc = 3; else if (n.split(/\s+/).some(w => w.startsWith(q))) sc = 2; else if (n.includes(q)) sc = 1;
    if (dg.length >= 2 && ph.includes(dg)) sc = Math.max(sc, ph.startsWith(dg) || ph.endsWith(dg) ? 3 : 2);
    if (sc) R.push({ c, sc }); });
  return R.sort((a, b) => b.sc - a.sc || custSales(b.c.id).length - custSales(a.c.id).length).slice(0, max || 8).map(x => x.c); }
const stars = n => !n ? '' : n <= 5 ? '⭐'.repeat(n) : '⭐ ×' + n;
const USD = n => '$' + ((n || 0) / (D.set.rate || 1680)).toFixed(2);

/* ---------- load / save ---------- */
function fix() {
  COLS.forEach(c => { if (!Array.isArray(D[c])) D[c] = []; });
  for (const k in SEED) if (!D[k].length) D[k] = JSON.parse(JSON.stringify(SEED[k]));
  D.set = Object.assign({}, DEFSET, D.set || {}); D.set.shop = Object.assign({}, DEFSET.shop, D.set.shop || {});
  { const own = D.users.find(u => u.n === 'bigshow') || D.users[0]; if (own && own.r !== 'a') own.r = 'a'; }   // the owner always has every right
  { const k = D.users.find(u => u.n === 'خەتاب'); if (k && !k.kh1) { k.r = 'c'; k.pm = ['pos','hold','cdel','cust','sret','buy','out','box','close','rate','today','theme']; k.pv2 = 1; k.kh1 = 1; } }   // rights the owner chose for خەتاب (once)
  { const k = D.users.find(u => u.n === 'خەتاب'); if (k && !k.kh2) { k.r = 'c'; k.pm = ['pos','hold','cdel','buy','box','today','rate','close','theme']; k.pv2 = 1; k.kh1 = 1; k.kh2 = 1; } }   // 23/11: owner's list for خەتاب — sale, buy, box + today report, dollar rate, daily close, design
  D.users.forEach(u => { if (u.r === 'a') return; if (!u.pm) u.pm = [];
    if (!u.pv2) { const add = k => { if (!u.pm.includes(k)) u.pm.push(k); };            // keep what an existing cashier could already do
      if (u.pm.includes('pos')) ['hold','nr','cdel'].forEach(add); if (u.disc) ['disc','gift'].forEach(add); u.pv2 = 1; } });
  if (D.set.fxv !== 2) { D.fixed = [{ id:1, n:'کرێی دوکان', h:[[0, 15000]] }, { id:2, n:'کرێی کارمەند', h:[[0, 20000]] }]; D.set.fxv = 2; }   // daily fixed costs (owner sets them)
}
function snap() { SNAP = {}; COLS.forEach(c => { const m = SNAP[c] = new Map(); (D[c] || []).forEach(x => m.set(x.id, JSON.stringify(x))); });
  SNAP.$set = JSON.stringify(D.set); SNAPIMG = Object.assign({}, IMG); }
async function boot() {
  if (API) { let r;
    // while the data loads, cover the screen so nothing can be clicked with no user / no rights
    const ov = document.createElement('div'); ov.id = 'bs-wait'; ov.style.cssText = 'position:fixed;inset:0;z-index:999999;background:rgba(0,0,0,.55);color:#fff;display:none;align-items:center;justify-content:center;font:bold 22px NRT,Tahoma,sans-serif;text-align:center;line-height:1.8';
    ov.innerHTML = '⏳ چاوەڕێ بکە، داتاکان بار دەکرێن...'; const sh = setTimeout(() => { if (document.body) { document.body.appendChild(ov); ov.style.display = 'flex'; } }, 5000);
    try { r = await API.storeLoad(); }
    catch (e) { clearTimeout(sh); if (document.body && !ov.parentNode) document.body.appendChild(ov); ov.style.display = 'flex';
      ov.innerHTML = '⚠️ پەیوەندی بە داتابەیسەوە پچڕا<br>خۆکارانە دووبارە هەوڵ دەدرێتەوە...'; setTimeout(() => location.reload(), 3000); throw e; }
    clearTimeout(sh); ov.remove();
    D = r.D || {}; IMG = r.IMG || {}; D.set = D.$set; delete D.$set; UNDO = D.$undo || []; delete D.$undo; }
  else { try { D = JSON.parse(localStorage.getItem('bs_demo')) || {}; IMG = JSON.parse(localStorage.getItem('bs_demo_img')) || {}; UNDO = JSON.parse(localStorage.getItem('bs_demo_undo')) || []; } catch (e) { D = {}; } }
  COLS.forEach(c => { if (!Array.isArray(D[c])) D[c] = []; }); D.set = D.set || null;
  snap();                                   // what is really in the database now
  fix(); if (!API && !D.products.length) demoData();
  await save();                             // writes only what fix()/demo added (first start)
  try { const id = +sessionStorage.getItem('bs_user'); U = D.users.find(u => u.id === id) || null; } catch (e) {}
  setTimeout(shrinkImages, 1500);
  return C;
}
let saving = Promise.resolve();
function save() {
  const ops = [], now = Date.now();
  { const m = SNAP.products || new Map(); D.products.forEach(p => { const o = m.get(p.id); const pq = o ? JSON.parse(o).q : null;   // remember when the full bottles ran out
      if (p.q <= 0 && (pq == null || pq > 0) && !p.zt) p.zt = now; if (p.q > 0 && p.zt) delete p.zt; }); }
  COLS.forEach(c => { const m = SNAP[c] || new Map(), seen = new Set();
    D[c].forEach(x => { seen.add(x.id); const j = JSON.stringify(x); if (m.get(x.id) !== j) ops.push({ t:'put', c, o:x }); });
    m.forEach((j, id) => { if (!seen.has(id)) ops.push({ t:'del', c, id }); }); });
  if (JSON.stringify(D.set) !== SNAP.$set) ops.push({ t:'kv', k:'set', v:D.set });
  for (const k in IMG) if (IMG[k] !== SNAPIMG[k]) ops.push({ t:'img', id:k, v:IMG[k] });
  for (const k in SNAPIMG) if (!(k in IMG)) ops.push({ t:'img', id:k, v:null });
  if (!ops.length) return saving;
  if (!UNDOING) { const ch = []; ops.forEach(o => { if (o.t === 'img' || o.c === 'log') return; if (o.t === 'kv') { ch.push({ c:'$set', prev:SNAP.$set || null }); return; }
      const id = o.t === 'put' ? o.o.id : o.id; ch.push({ c:o.c, id, prev:(SNAP[o.c] && SNAP[o.c].get(id)) || null }); });
    if (ch.some(x => x.c !== '$set') && LBL.length) { UNDO.push({ id:uid(), t:now, u:U ? U.n : '—', a:LBL.join(' · ').slice(0, 300), ch }); if (UNDO.length > 20) UNDO.splice(0, UNDO.length - 20);
      ops.push({ t:'kv', k:'undo', v:UNDO }); } }
  LBL = [];
  const oldSnap = SNAP, oldImg = SNAPIMG;
  snap();
  saving = saving.then(() => API ? API.storeTx(ops) : (localStorage.setItem('bs_demo', JSON.stringify(D)), localStorage.setItem('bs_demo_img', JSON.stringify(IMG)), localStorage.setItem('bs_demo_undo', JSON.stringify(UNDO))))
    .catch(e => { SNAP = oldSnap; SNAPIMG = oldImg;      // nothing is lost: the same changes are written again
      console.error('save failed', e); if (!save.warned) { save.warned = 1; alert('⚠️ پەیوەندی بە داتابەیسەوە بۆ ساتێک پچڕا. هیچ شتێک ون نابێت؛ بەرنامەکە خۆی دووبارە هەڵیدەگرێتەوە.'); }
      setTimeout(() => { save().then(() => { save.warned = 0; }); }, 3000); });
  return saving;
}

/* pictures brought from the old program can be big: make them small once (160px) so screens open fast */
async function shrinkImages() { if (typeof document === 'undefined') return; const big = Object.keys(IMG).filter(k => k !== 'logo' && IMG[k].length > 40000).slice(0, 60); if (!big.length) return;
  for (const k of big) await new Promise(res => { const im = new Image(); im.onload = () => { const f = Math.min(1, 160 / Math.max(im.width, im.height)), c = document.createElement('canvas');
    c.width = Math.max(1, Math.round(im.width * f)); c.height = Math.max(1, Math.round(im.height * f)); const x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height); x.drawImage(im, 0, 0, c.width, c.height);
    IMG[k] = c.toDataURL('image/jpeg', .78); res(); }; im.onerror = res; im.src = IMG[k]; });
  save(); }

/* ---------- users ---------- */
async function hashPw(p) { if (API && API.hash) return API.hash(p);
  const b = await crypto.subtle.digest('SHA-256', new TextEncoder().encode('bigshow:' + p)); return [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, '0')).join(''); }
const isA = () => !!(U && U.r === 'a');
const can = t => t === 'home' || isA() || !!(U && (U.pm || []).includes(PK[t] || t));
const cDisc = () => can('disc');
/* undo the last step (owner / users with the 'undo' right); every undo is logged and sent to Telegram */
const lastUndo = () => UNDO[UNDO.length - 1] || null;
async function undo() { const e = UNDO.pop(); if (!e) return false; UNDOING = true;
  try { e.ch.slice().reverse().forEach(x => { if (x.c === '$set') { if (x.prev) D.set = JSON.parse(x.prev); return; }
      const A = D[x.c]; if (!A) return; const k = A.findIndex(y => y.id === x.id);
      if (x.prev == null) { if (k >= 0) A.splice(k, 1); } else { const o = JSON.parse(x.prev); if (k >= 0) A[k] = o; else A.push(o); } });
    D.log.push({ id:uid(), t:Date.now(), u:U ? U.n : '—', a:'↩️ گەڕانەوەی هەنگاو: ' + e.a });
    tg('↩️ گەڕانەوەی هەنگاوی پێشوو:\n' + e.a + '\n(کراوە لەلایەن ' + e.u + ' ' + fTT(e.t) + ')');
    await save(); if (API) await API.storeTx([{ t:'kv', k:'undo', v:UNDO }]); else localStorage.setItem('bs_demo_undo', JSON.stringify(UNDO));
  } finally { UNDOING = false; } return true; }
async function login(id, pw) { const u = D.users.find(x => x.id === +id); if (!u || u.h !== await hashPw(pw)) return false;
  U = u; sessionStorage.setItem('bs_user', u.id); lg('چوونەژوورەوە'); await save(); return true; }
function logout() { if (U) lg('چوونەدەرەوە'); save(); U = null; sessionStorage.removeItem('bs_user'); }
const lg = a => { LBL.push(a); D.log.push({ id:uid(), t:Date.now(), u:U ? U.n : '—', a }); if (D.log.length > 5000) D.log.splice(0, D.log.length - 5000); };
const tg = text => (API && API.tg) ? API.tg(text + (U ? '\n👤 ' + U.n : '')) : Promise.resolve(false);     // live Telegram notice to the owner
// (2) suspicious-activity watch: counts per user per day on this PC; Telegram alert when a limit is reached (and every time again by the same amount)
const WLIM = { price:['گۆڕینی نرخ لە کاتی فرۆشتن', 5], ds:['فرۆشتن بە داشکاندن', 5], del:['سڕینەوەی ماددە لە سەبەتە', 5], clr:['سڕینەوەی هەموو سەبەتە', 3], ret:['گەڕاندنەوەی فرۆشتن', 2] };
const watch = (k, info) => { try { if (!U || U.n === 'bigshow') return; const day = new Date().toDateString(); let o = {}; try { o = JSON.parse(localStorage.getItem('bs_w') || '{}'); } catch (e) {}
  if (o.d !== day) o = { d:day, c:{} }; const id = U.n + '|' + k; o.c[id] = (o.c[id] || 0) + 1; localStorage.setItem('bs_w', JSON.stringify(o));
  const L = WLIM[k], n = o.c[id]; if (L && n >= L[1] && (n - L[1]) % L[1] === 0) tg('🚨 ئاگاداری کاری گومانلێکراو\n' + U.n + ' ئەمڕۆ ' + n + ' جار ' + L[0] + ' کردووە' + (info ? '\nدوایینیان: ' + info : '')); } catch (e) {} };

/* ---------- products, offers ---------- */
const P = id => D.products.find(p => p.id === id);
const ofr = p => { const t = Date.now(); return D.offers.filter(o => o.pid === p.id && t >= o.f && t < o.to + 864e5).pop(); };
const pr = p => { const o = ofr(p); return o ? o.pr : p.p; };
const mt = (p, v) => p.n.toLowerCase().includes(v) || (p.bc || '').includes(v) || (p.ih || '').toLowerCase().includes(v) || (p.br || '').toLowerCase().includes(v);
const coN = id => (D.cos.find(c => c.id === id) || { n:'—' }).n;
const catN = id => (D.cats.find(c => c.id === id) || { n:'—' }).n;
const boxN = id => (D.boxes.find(b => b.id === id) || { n:'قاسە' }).n;
function genBC() { let c; do { c = '2' + String(Math.floor(Math.random() * 1e11)).padStart(11, '0'); } while (D.products.some(p => p.bc === c)); return c; }

/* company debt = credit purchases - credit returns + manual debts - payments */
const cb = id => sa(D.pur.filter(p => p.co === id && p.py === 'debt'), p => p.ret ? -p.tot : p.tot) + sa(D.cdebt.filter(x => x.co === id), x => x.amt) - sa(D.cpay.filter(x => x.co === id), x => x.amt);

/* every money movement, per box */
function moves() { const R = [], b = x => x.box || 1;
  D.sales.forEach(s => R.push({ t:s.t, box:b(s), a:s.tot, l:'فرۆشتن' }));
  D.sret.forEach(x => R.push({ t:x.t, box:b(x), a:-x.amt, l:'گەڕاندنەوەی فرۆشتن' }));
  D.rets.forEach(x => R.push({ t:x.t, box:b(x), a:x.diff, l:'گۆڕینەوەی بۆن' }));
  D.pur.forEach(x => { if (x.py === 'cash') R.push({ t:x.t, box:b(x), a:x.ret ? x.tot : -x.tot, l:x.ret ? 'گەڕانەوەی کڕین' : 'کڕینی کاش' }); });
  D.cpay.forEach(x => R.push({ t:x.t, box:b(x), a:-x.amt, l:'دانەوەی قەرزی کۆمپانیا' }));
  D.exp.forEach(x => R.push({ t:x.t, box:b(x), a:-x.amt, l:'خەرجی' }));
  D.sal.forEach(x => R.push({ t:x.t, box:b(x), a:-x.amt, l:'مووچە' }));
  D.cash.forEach(x => { if (x.ty === 'tr') { R.push({ t:x.t, box:x.from, a:-x.amt, l:'گواستنەوە' }); R.push({ t:x.t, box:x.to, a:x.amt, l:'گواستنەوە' }); }
    else R.push({ t:x.t, box:b(x), a:x.ty === 'in' ? x.amt : -x.amt, l:x.ty === 'in' ? 'دانانەوەی پارە' : 'ڕاکێشانی پارە' }); });
  D.close.forEach(x => { if (x.diff) R.push({ t:x.t, box:x.box, a:x.diff, l:'جیاوازی داخستنی سندوق' }); });
  return R.filter(m => m.box > 0); }     // box -1 = history from the old program
const bal = bx => sa(moves().filter(m => bx == null || m.box === bx), m => m.a);

/* ---------- daily fixed costs: the owner writes a name + amount per day; a change counts from that day on ---------- */
const fxAmt = (c, day) => { const t = +d0(day); let a = 0; (c.h || []).forEach(h => { if (h[0] <= t) a = h[1]; }); return a; };
const fxShare = (c, day) => fxAmt(c, day);
const fxDay = day => sa(D.fixed, c => fxAmt(c, day));
const fxRange = (f, t) => { let s = 0; for (let d = d0(f); d <= d0(t); d = addD(d, 1)) s += fxDay(d); return s; };

/* ---------- report numbers (same rules as the tested version) ---------- */
function stats(f, t) { const a = +d0(f), b = +addD(d0(t), 1), inR = x => x.t >= a && x.t < b, S = D.sales.filter(inR);
  const o = { S, n:S.length, sales:0, cost:0, ds:0, qty:0 };
  S.forEach(s => { o.sales += s.tot; o.ds += s.ds || 0; s.items.forEach(i => { o.cost += (i.c || 0) * i.q; o.qty += i.q; }); });
  const R = D.sret.filter(inR), W = D.rets.filter(inR);
  o.ret = sa(R, x => x.amt); o.retc = sa(R, x => sa(x.items, i => (i.c || 0) * i.q));
  o.profit = o.sales - o.cost - (o.ret - o.retc) + sa(W, x => sa(x.ro, i => (i.p - i.c) * i.q) - sa(x.ri, i => (i.p - i.c) * i.q));
  o.avg = o.n ? o.sales / o.n : 0; o.mg = o.sales ? o.profit / o.sales * 100 : 0;
  o.xp = sa(D.exp.filter(inR), x => x.amt); o.sl = sa(D.sal.filter(inR), x => x.amt); o.xs = o.xp + o.sl;
  o.dmg = sa((D.adj || []).filter(x => inR(x) && x.dmg), x => -x.v);
  o.fixed = fxRange(f, t); o.ap = D.set.ap != null ? +D.set.ap : 5; o.auto = Math.round(Math.max(0, o.profit) * o.ap / 100);   // automatic expense: 5% of the profit
  o.net = o.profit - o.xs - o.fixed - o.auto; o.nr = S.filter(s => s.nr).length; return o; }


/* ---------- finished / low products, with last purchase price (for re-ordering from the wholesaler) ---------- */
function lastBuy(id) { for (let k = D.pur.length - 1; k >= 0; k--) { const b = D.pur[k]; if (b.ret) continue; const i = b.items.find(x => x.id === id); if (i) return { c:i.c, co:b.co, t:b.t, q:i.q }; }
  const p = P(id) || {}; return { c:p.c || 0, co:p.co || 0, t:0, q:1 }; }
/* "finished" = every full bottle is sold (only the tester may be left) */
function outList(todayOnly) { const t0 = today(); return D.products.filter(p => p.q <= 0 && (!todayOnly || (p.zt || 0) >= t0)).map(p => { const lb = lastBuy(p.id);
  return { id:p.id, n:p.n, br:p.br || '', ml:p.sz || '', q:p.q, ts:p.t || 0, c:lb.c, co:lb.co, t:lb.t, zt:p.zt || 0, need:Math.max(1, lb.q || 1) }; }).sort((a, b) => (b.zt - a.zt) || a.n.localeCompare(b.n)); }
function outTxt(todayOnly) { const L = outList(todayOnly); if (!L.length) return todayOnly ? '✅ ئەمڕۆ هیچ بۆنێک تەواو نەبووە' : '✅ هیچ بۆنێک تەواو نەبووە';
  const G = {}; L.forEach(x => (G[x.co || 0] = G[x.co || 0] || []).push(x));
  return `🚫 ${todayOnly ? 'مادە تەواوبووەکانی ئەمڕۆ' : 'مادە تەواوبووەکان'} (${L.length}) — ${fd(new Date())}\n` + Object.entries(G).map(([co, A]) => `\n🏪 ${+co ? coN(+co) : 'نەزانراو'}\n` +
    A.map((x, i) => `${i + 1}. ${x.n}${x.ml ? ' ' + x.ml + 'ml' : ''} — داواکردن: ${x.need} دانە · نرخی پێشوو ${n0(x.c)}${x.ts ? ' · 🧪 تێستەر ماوە' : ''}`).join('\n')).join('\n') +
    `\n\n━━━━\nبەهای کڕینەوە (بە نرخی پێشوو): ${n0(sa(L, x => x.c * x.need))}`; }

/* ---------- daily summary text (Telegram 4:30) ---------- */
function dayTxt(day) { const t0 = +d0(day || new Date()), t1 = t0 + 864e5, inD = x => x.t >= t0 && x.t < t1, S = D.sales.filter(inD), o = stats(new Date(t0), new Date(t0));
  let t = `📊 کورتەی ڕۆژی ${fd(new Date(t0))} — ${D.set.shop.n}\n\n🧾 فرۆشتنەکان:\n`;
  S.forEach(s => { t += `\n⏰ ${hm(s.t)} · پسوولە #${s.no}${s.emp ? ' · ' + s.emp : ''}\n`; s.items.forEach(i => t += `• ${i.n}${i.ts ? ' (تێستەر)' : ''}${i.gift ? ' (دیاری)' : ''} ×${i.q} | کڕین ${n0(i.c)} | فرۆشتن ${n0(i.p)}\n`);
    if (s.ds) t += `  داشکاندن: ${n0(s.ds)}\n`; t += `  کۆی گشتی: ${n0(s.tot)}\n`; });
  if (!S.length) t += 'هیچ فرۆشتنێک نییە\n';
  D.sret.filter(inD).forEach(x => t += `\n↩️ ${hm(x.t)} گەڕانەوەی پسوولە #${x.no}: ${x.items.map(i => i.n + ' ×' + i.q).join('، ')} = ${n0(x.amt)}\n`);
  [...D.exp.filter(inD).map(x => ({ t:x.t, l:x.cat, a:x.amt })), ...D.sal.filter(inD).map(x => ({ t:x.t, l:'مووچەی ' + x.emp, a:x.amt }))].sort((a, b) => a.t - b.t).forEach(x => t += `\n📝 ${hm(x.t)} ${x.l}: ${n0(x.a)}`);
  t += `\n\n━━━━━━━━\n💵 فرۆشتن: ${n0(o.sales)}\n📦 تێچووی کڕینی مادەکان: ${n0(o.cost)}\n🏷️ داشکاندن: ${n0(o.ds)}\n↩️ گەڕانەوەی مادەکان: ${n0(o.ret)}\n📈 قازانجی ئەمڕۆ: ${n0(o.profit)}\n📝 خەرجی ئەمڕۆ: ${n0(o.xs)}\n📌 خەرجی جێگیر: ${n0(o.fixed)}\n🔖 ${o.ap}٪ لە قازانج (خەرجی خۆکار): ${n0(o.auto)}\n✅ قازانجی پاک: ${n0(o.net)}\n🧾 ژمارەی پسوولە: ${o.n}`;
  return t; }

/* ---------- amount in Kurdish words (stock footer, receipts) ---------- */
function words(n) { n = Math.round(n); if (!n) return 'سفر';
  const o = ['','یەک','دوو','سێ','چوار','پێنج','شەش','حەوت','هەشت','نۆ','دە','یازدە','دوازدە','سیازدە','چواردە','پازدە','شازدە','حەڤدە','هەژدە','نۆزدە'],
    tt = ['','','بیست','سی','چل','پەنجا','شەست','حەفتا','هەشتا','نەوەد'], h = ['','سەد','دووسەد','سێسەد','چوارسەد','پێنجسەد','شەشسەد','حەوتسەد','هەشتسەد','نۆسەد'];
  const u = x => { const p = []; if (x >= 100) { p.push(h[Math.floor(x / 100)]); x %= 100; } if (x >= 20) { p.push(tt[Math.floor(x / 10)]); x %= 10; } if (x) p.push(o[x]); return p.join(' و '); };
  const p = [], m = Math.floor(n / 1e6), k = Math.floor(n % 1e6 / 1000), r = n % 1000;
  if (m) p.push(u(m) + ' ملیۆن'); if (k) p.push(k === 1 ? 'هەزار' : u(k) + ' هەزار'); if (r) p.push(u(r)); return p.join(' و '); }

/* ---------- images (resized to ~160px, stored in SQL) ---------- */
function imgIn(f, max, type, cb) { if (!f) return; const r = new FileReader(); r.onload = () => { const im = new Image(); im.onload = () => {
  const k = Math.min(1, max / Math.max(im.width, im.height)), c = document.createElement('canvas'); c.width = Math.max(1, Math.round(im.width * k)); c.height = Math.max(1, Math.round(im.height * k));
  const x = c.getContext('2d'); if (type === 'image/jpeg') { x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height); } x.drawImage(im, 0, 0, c.width, c.height); cb(c.toDataURL(type, .78)); }; im.src = r.result; }; r.readAsDataURL(f); }
const IM = (p, cls) => p && IMG[p.id] ? `<img class="${cls || 'im'}" src="${IMG[p.id]}" alt="">` : `<div class="${cls || 'im'} noimg">🧴</div>`;

/* ---------- preview data (only when opened in a normal browser, never in the program) ---------- */
function demoData() {
  const L = [['mini original','1',5500,17000,0,1],['گچکە خمرا','2',2000,15000,3,2],['saheb mini','3',3000,15000,4,1],['MANCERA RED TOBACCO Master','11',13500,25000,2,3],
    ['CREED MASTER','15',13500,25000,1,3],['قاپیشی جلدی اسلی66','66',2500,8000,106,4],['معطر جسم 4000','88',2750,4000,77,5],['Oldspice','200',2750,10000,22,2],
    ['TEA ROSE','8952002134',6000,15000,2,2],['OUD SAFFRON','20250441057',14000,50000,2,2],['GOLD 360','20250470001',20000,35000,5,2],['AMOUR MPF 1','20250470002',14000,25000,1,2]];
  D.products = L.map((x, i) => ({ id:i + 1, n:x[0], bc:x[1], c:x[2], p:x[3], q:x[4], cat:x[5], co:0, br:'', ih:'', sz:100, g:'پیاو', t:i % 4 === 0 ? 1 : 0, m:2 }));
  D.users = [{ id:1, n:'bigshow', r:'a', h:'' }, { id:2, n:'خەتاب', r:'c', h:'', pm:DPM.slice(), disc:true }];
}

function use(d) { D = d; fix(); }
const C = window.C = { boot, save, use, get D() { return D; }, get IMG() { return IMG; }, get U() { return U; }, API, COLS, DPM,
  nd, E, N, n0, p2, fd, fT, fTT, hm, d0, today, iso, fromIso, addD, sa, sm, uid, stars, tier, custSales, custInfo, custFind, USD, hashPw, isA, can, cDisc, login, logout, lg, tg,
  P, ofr, pr, mt, coN, catN, boxN, genBC, cb, moves, bal, fxShare, fxRange, fxAmt, fxDay, PERMS, lastUndo, undo, watch, LOGOBW, stats, dayTxt, lastBuy, outList, outTxt, words, imgIn, IM };
})();
