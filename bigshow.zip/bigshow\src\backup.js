/* (19) Automatic daily backup + copy to Telegram */
const fs = require('fs');
const path = require('path');

function stamp(d = new Date()) {
  const p = n => String(n).padStart(2, '0');
  return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()) + '_' + p(d.getHours()) + p(d.getMinutes());
}

async function backupNow(db, cfg, telegram) {
  const B = Object.assign({ folder: 'C:\\POS-Backup', keepDays: 30, sendToTelegram: true }, cfg.backup || {}), folder = B.folder;
  fs.mkdirSync(folder, { recursive: true });
  // SQL Server writes the file itself, so the folder must be writable by the SQL Server service (see README).
  let file = path.join(folder, 'bigshow_pos_' + stamp() + '.bak');
  try { await db.run(`BACKUP DATABASE [bigshow_pos] TO DISK = @file WITH INIT, NAME = 'Bigshow POS daily backup'`, { file }); }
  catch (e) {
    // SQL Server could not write there (folder rights) → export all data ourselves as a compressed file instead
    const zlib = require('zlib'), pool = db.getPool(), out = {};
    for (const t of ['bs_doc', 'bs_kv', 'bs_img']) { try { out[t] = (await pool.request().query('SELECT * FROM ' + t)).recordset; } catch (x) {} }
    file = path.join(folder, 'bigshow_data_' + stamp() + '.json.gz');
    fs.writeFileSync(file, zlib.gzipSync(Buffer.from(JSON.stringify(out))));
  }

  // keep only the last N days
  const keep = (B.keepDays || 30) * 24 * 3600 * 1000;
  for (const f of fs.readdirSync(folder)) {
    const full = path.join(folder, f);
    if ((f.endsWith('.bak') || f.endsWith('.json.gz')) && Date.now() - fs.statSync(full).mtimeMs > keep) fs.unlinkSync(full);
  }

  if (B.sendToTelegram && telegram && telegram.ready()) {
    const size = fs.statSync(file).size;
    if (size < 49 * 1024 * 1024) await telegram.sendDocument(file, '💾 Backup ـی ڕۆژانە — ' + stamp().replace('_', ' '));
    else await telegram.send('💾 Backup کرا (' + Math.round(size / 1048576) + ' MB) — گەورەترە لەوەی بنێردرێت بۆ تێلێگرام، لە ' + folder + ' هەڵگیراوە.');
  }
  return { ok: true, file };
}

function schedule(db, cfg, telegram, log) {
  let lastDay = '';
  setInterval(async () => {
    const now = new Date(), hm = now.toTimeString().slice(0, 5), day = now.toDateString();
    if (hm >= ((cfg.backup && cfg.backup.time) || '16:45') && lastDay !== day) {
      lastDay = day;
      try { const r = await backupNow(db, cfg, telegram); log('backup ok ' + r.file); }
      catch (e) { log('backup error ' + e.message); if (telegram && telegram.ready()) telegram.send('⚠️ Backup سەرکەوتوو نەبوو: ' + e.message); }
    }
  }, 60 * 1000);
}

module.exports = { backupNow, schedule };
