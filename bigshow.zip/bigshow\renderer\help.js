/* 🆘 یارمەتی: پرسیارە ئامادەکراوەکان + ناردنی پرسیار (نووسین یان ڤۆیس) بۆ گەشەپێدەر لە تەلێگرام، و وەڵامەکەی دەگەڕێتەوە ناو بەرنامە */
(function () {
  const FAQ = [
    ['چۆن بۆنێکی نوێ تۆمار بکەم؟', 'لە شاشەی سەرەکی «تۆمارکردنی مادە» دابگرە (یان لە مێنیوی سەرەوە: مادە و کۆگا ← تۆمار و دەستکاریی بۆن). ناو، جۆر، نرخی کڕین، نرخی فرۆشتن، بڕ و بارکۆد بنووسە، پاشان پاشەکەوتی بکە.'],
    ['چۆن جۆری مادە زیاد بکەم (بۆنی پیاوان، ئافرەتان...)؟', 'مێنیوی سەرەوە: مادە و کۆگا ← جۆری مادە. ناوی جۆرەکە بنووسە و زیادی بکە. دواتر لە کاتی تۆمارکردنی بۆن جۆرەکە هەڵبژێرە.'],
    ['چۆن بفرۆشم و پسوڵە چاپ بکەم؟', 'بچۆ بەشی فرۆشتن. بارکۆدی بۆنەکە سکان بکە یان ناوەکەی بگەڕێ. کە هەموو مادەکان زیاد بوون، فرۆشتن تەواو بکە؛ پسوڵە خۆکار چاپ دەبێت.'],
    ['چۆن زانیاریی کڕیار تۆمار بکەم؟', 'لە شاشەی سەرەکی «کڕیارەکان» دابگرە. ناو و ژمارەی مۆبایلی کڕیار بنووسە و پاشەکەوتی بکە. لە کاتی فرۆشتن دەتوانیت کڕیارەکە هەڵبژێریت.'],
    ['چۆن کڕین لە جوملە (کۆمپانیا) تۆمار بکەم؟', 'یەکەم جار جوملەکە لە «کۆمپانیاکان» زیاد بکە. پاشان «کڕینی مادە»: جوملە هەڵبژێرە، مادەکان و بڕ و نرخی کڕین بنووسە، و دیاری بکە نەقدە یان قەرز.'],
    ['چۆن قەرزی جوملە بدەمەوە؟', 'لە شاشەی سەرەکی «دانەوەی قەرزی کۆمپانیا». جوملەکە هەڵبژێرە و بڕی پارەکە بنووسە. «کەشفی حسابی کۆمپانیا» هەموو قەرز و پارەدانەکان پیشان دەدات.'],
    ['کڕیار بۆنێکی گەڕاندەوە، چی بکەم؟', '«گەڕاندنەوەی فرۆشتن»: پسوڵەکە سکان بکە یان ژمارەکەی بنووسە، و ئەو مادەیەی دەگەڕێتەوە هەڵبژێرە. ئەگەر بۆنێکی تری بەجێی ویست، «گۆڕینەوەی بۆن» بەکاربهێنە.'],
    ['چۆن خەرجی تۆمار بکەم؟', '«تۆمارکردنی خەرجی»: جۆری خەرجی و بڕەکە بنووسە. بۆ مووچەی کارمەند «پێدانی مووچە» بەکاربهێنە.'],
    ['کرێی دوکان و مووچە چۆن خۆکار لە قازانج دەربکرێن؟', 'مێنیوی سەرەوە: پارە ← خەرجیی ڕۆژانەی خۆکار. ناوی خەرجییەکە (نموونە: کرێی دوکان) و بڕی ڕۆژانەی بنووسە. لەو ڕۆژەوە هەموو ڕۆژێک لە قازانج دەردەکرێت. ئەگەر هیچت نەنووسیبێت، هیچ خەرجییەکی ڕۆژانە دەرناکرێت.'],
    ['ڕاپۆرتی فرۆشتن و قازانج لە کوێیە؟', '«ڕاپۆرتی ئەمڕۆ» بۆ ئەمڕۆ. بۆ چەند ڕۆژ یان مانگێک: مێنیوی سەرەوە: ڕاپۆرت ← ڕاپۆرتی گشتی و قازانج.'],
    ['چۆن کاشێر یان بەکارهێنەری نوێ دروست بکەم؟', 'تەنها بەڕێوەبەر دەتوانێت: مێنیوی سەرەوە: سیستەم ← بەکارهێنەران و دەسەڵات. ناو و وشەی نهێنی بنووسە و دەسەڵاتەکانی دیاری بکە.'],
    ['ناوی دوکان و نووسینی سەر پسوڵە چۆن بگۆڕم؟', 'مێنیوی سەرەوە: سیستەم ← ڕێکخستنی دوکان و پسوڵە.'],
    ['پسوڵە چاپ نابێت، چی بکەم؟', 'دڵنیابە پرێنتەرەکە هەڵکراوە، کاغەزی تێدایە و بە USB پەیوەستە. لە ویندۆز بچۆ Settings ← Printers و دڵنیابە پرێنتەرەکە دامەزراوە. پاشان بەرنامەکە دابخە و بیکەرەوە. ئەگەر هێشتا چاپ نەبوو، لە خوارەوە پرسیار بنێرە.'],
    ['سکانەری بارکۆد کار ناکات؟', 'سکانەر وەک کیبۆرد کار دەکات: پێش سکان کرتە لە خانەی گەڕان بکە. زمانی کیبۆردی ویندۆز بکە بە English. سکانەرەکە بکێشە دەرەوە و دووبارە بیخەرەوە.'],
    ['نرخی دۆلار چۆن بگۆڕم؟', 'مێنیوی سەرەوە: پارە ← نرخی دۆلار.'],
    ['کۆتایی ڕۆژ چی بکەم؟', 'مێنیوی سەرەوە: پارە ← داخستنی سندوق. پارەی ناو دەخیلە بژمێرە و تۆماری بکە.'],
    ['چۆن باکئەپ (پاراستن) بکەم؟', 'لە شاشەی سەرەکی «پاراستنی سیستەم (Backup)» دابگرە. بەرنامەکە خۆی ڕۆژانەش باکئەپ دەکات.']
  ];
  const KEY = 'bs-help';
  const load = () => { try { return JSON.parse(localStorage.getItem(KEY)) || []; } catch (e) { return []; } };
  const keep = L => { try { localStorage.setItem(KEY, JSON.stringify(L.slice(-30))); } catch (e) {} };
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;' }[c]));
  const fT = t => { const d = new Date(t); return d.toLocaleDateString('en-GB') + ' ' + d.toTimeString().slice(0, 5); };

  const css = document.createElement('style');
  css.textContent = `
  #helpbtn { left:337px; top:551px; width:93px; height:40px; background:#1565C0; color:#fff; border-radius:var(--radius,6px); display:flex; align-items:center; justify-content:center; font-size:14px; cursor:pointer; user-select:none; }
  #helpbtn:hover { background:#0D47A1; }
  #helpbtn i { position:absolute; top:-6px; left:-6px; background:#D32F2F; color:#fff; border-radius:10px; font:bold 11px Tahoma; padding:2px 6px; font-style:normal; display:none; }
  #helpov { position:fixed; inset:0; background:rgba(10,12,30,.6); z-index:99990; display:none; align-items:center; justify-content:center; font-family:NRT,Tahoma,sans-serif; }
  #helpov.show { display:flex; }
  #helpbox { width:min(760px,94vw); height:min(600px,92vh); background:#fff; color:#1B2747; border-radius:14px; display:flex; flex-direction:column; overflow:hidden; direction:rtl; box-shadow:0 20px 50px rgba(0,0,0,.4); }
  #helpbox .hd { background:#1B2747; color:#fff; padding:12px 18px; font-size:18px; display:flex; justify-content:space-between; align-items:center; }
  #helpbox .hd b { cursor:pointer; font-size:22px; }
  #helpbox .bd { flex:1; overflow-y:auto; padding:12px 18px; }
  #helpbox h4 { margin:14px 0 8px; font-size:16px; }
  .hq { border:1px solid #dde3ee; border-radius:8px; margin-bottom:6px; }
  .hq > div:first-child { padding:9px 12px; cursor:pointer; font-size:14.5px; }
  .hq > div:first-child:before { content:'➕ '; }
  .hq.open > div:first-child:before { content:'➖ '; }
  .hq > div + div { display:none; padding:0 12px 10px; font-size:14px; line-height:1.8; color:#333; }
  .hq.open > div + div { display:block; }
  #hq-t { width:100%; height:70px; box-sizing:border-box; border:1px solid #c5cde0; border-radius:8px; padding:8px; font:14px NRT,Tahoma; resize:none; }
  .hrow { display:flex; gap:8px; margin-top:8px; align-items:center; flex-wrap:wrap; }
  .hb { padding:9px 16px; border-radius:8px; cursor:pointer; color:#fff; background:#1565C0; font-size:14px; user-select:none; }
  .hb.rec { background:#6A1B9A; } .hb.rec.on { background:#D32F2F; }
  #hq-msg { font-size:13px; color:#555; }
  .hm { background:#f4f6fb; border-radius:8px; padding:8px 12px; margin-bottom:8px; font-size:14px; line-height:1.7; }
  .hm .a { background:#E8F5E9; border-radius:6px; padding:6px 10px; margin-top:6px; }
  .hm .w { color:#999; font-size:12.5px; }`;
  document.head.appendChild(css);

  function init() {
    const anchor = document.getElementById('quick'); if (!anchor) return;
    const b = document.createElement('div'); b.id = 'helpbtn'; b.className = 'abs'; b.innerHTML = '❓ یارمەتی<i id="helpdot">!</i>';
    anchor.parentNode.appendChild(b);
    const ov = document.createElement('div'); ov.id = 'helpov';
    ov.innerHTML = `<div id="helpbox"><div class="hd"><span>❓ یارمەتی</span><b id="hclose">✕</b></div><div class="bd">
      <h4>📚 پرسیارە ئامادەکراوەکان</h4><div id="hfaq">${FAQ.map(q => `<div class="hq"><div>${esc(q[0])}</div><div>${esc(q[1])}</div></div>`).join('')}</div>
      <h4>💬 وەڵامی پرسیارەکەت نەدۆزییەوە؟ بینووسە یان بە ڤۆیس بینێرە</h4>
      <textarea id="hq-t" placeholder="کێشەکەت لێرە بنووسە..."></textarea>
      <div class="hrow"><div class="hb" id="hq-send">📨 ناردن</div><div class="hb rec" id="hq-rec">🎤 تۆمارکردنی ڤۆیس</div><span id="hq-msg"></span></div>
      <h4>📥 پرسیار و وەڵامەکانت</h4><div id="hq-list"></div></div></div>`;
    document.body.appendChild(ov);
    ov.querySelectorAll('.hq > div:first-child').forEach(d => d.onclick = () => d.parentNode.classList.toggle('open'));
    b.onclick = () => { ov.classList.add('show'); draw(); poll(); };
    document.getElementById('hclose').onclick = () => ov.classList.remove('show');
    document.getElementById('hq-send').onclick = () => send(document.getElementById('hq-t').value.trim(), null);
    document.getElementById('hq-rec').onclick = rec;
    poll(); setInterval(poll, 60000);
  }

  function who() { let u = '-'; try { u = (window.C && C.U && C.U.n) || '-'; } catch (e) {}
    const s = document.getElementById('shopname'); return { user:u, shop:s ? s.textContent.trim() : '-' }; }
  const msg = t => { const m = document.getElementById('hq-msg'); if (m) m.textContent = t; };

  async function send(q, voice) {
    if (!q && !voice) return msg('⚠️ پێش ناردن کێشەکەت بنووسە یان ڤۆیس تۆمار بکە');
    if (!(window.api && api.helpSend)) return msg('⚠️ ئەم بەشە لەم وەشانەدا کار ناکات');
    msg('⏳ دەنێردرێت...');
    const r = await api.helpSend(q, who(), voice);
    if (!r || !r.ok) return msg(r && r.why === 'no-token' ? '⚠️ پشتگیری هێشتا ڕێکنەخراوە' : r && r.why === 'chat' ? '⚠️ گەشەپێدەر هێشتا Start ی لە بۆتی یارمەتی نەکردووە' : '⚠️ نەنێردرا (' + ((r && r.why) || '?') + '). دڵنیابە ئینتەرنێت هەیە و دووبارە هەوڵبدەرەوە');
    const L = load(); L.push({ id:r.id, q:q || '🎤 ڤۆیس', t:Date.now(), a:[] }); keep(L);
    document.getElementById('hq-t').value = ''; msg('✅ نێردرا. کاتێک وەڵام هات، لێرە دەردەکەوێت'); draw();
  }

  function draw() { const el = document.getElementById('hq-list'); if (!el) return; const L = load().slice().reverse();
    el.innerHTML = L.length ? L.map(x => `<div class="hm"><div class="w">${fT(x.t)}</div>❓ ${esc(x.q)}${x.a.length ? x.a.map(a => `<div class="a">💬 ${esc(a.text)}</div>`).join('') : '<div class="w">⏳ چاوەڕێی وەڵام...</div>'}</div>`).join('') : '<div class="w">هێشتا هیچ پرسیارێکت نەناردووە</div>';
    L.forEach(x => x.seen = true); const all = load(); all.forEach(x => { x.seen = true; }); keep(all);
    const dot = document.getElementById('helpdot'); if (dot) dot.style.display = 'none'; }

  async function poll() { const L = load(); const ids = L.filter(x => Date.now() - x.t < 86400000).map(x => x.id);
    if (!ids.length || !(window.api && api.helpReplies)) return;
    const R = await api.helpReplies(ids); let fresh = false;
    R.forEach(r => { const x = L.find(y => y.id === r.to); if (x && !x.a.some(a => a.mid === r.mid)) { x.a.push(r); x.seen = false; fresh = true; } });
    if (!fresh) return; keep(L);
    const open = document.getElementById('helpov') && document.getElementById('helpov').classList.contains('show');
    if (open) draw(); else { const dot = document.getElementById('helpdot'); if (dot) dot.style.display = 'block'; } }

  let mr = null, parts = [];
  async function rec() { const btn = document.getElementById('hq-rec');
    if (mr && mr.state === 'recording') { mr.stop(); return; }
    try { const st = await navigator.mediaDevices.getUserMedia({ audio:true }); parts = []; mr = new MediaRecorder(st);
      mr.ondataavailable = e => parts.push(e.data);
      mr.onstop = async () => { st.getTracks().forEach(t => t.stop()); btn.classList.remove('on'); btn.textContent = '🎤 تۆمارکردنی ڤۆیس';
        const buf = new Uint8Array(await new Blob(parts, { type:'audio/webm' }).arrayBuffer()); send(document.getElementById('hq-t').value.trim(), buf); };
      mr.start(); btn.classList.add('on'); btn.textContent = '⏹️ وەستاندن و ناردن'; msg('🔴 قسە بکە... کە تەواو بوو «وەستاندن و ناردن» دابگرە');
    } catch (e) { msg('⚠️ مایکرۆفۆن نەدۆزرایەوە یان ڕێگەی پێنەدراوە'); } }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
