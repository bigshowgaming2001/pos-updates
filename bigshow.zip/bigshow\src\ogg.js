/* 🎤 WebM (Chrome recorder) → Ogg Opus, so Telegram shows a real playable voice message */
function webmToOgg(buf) {
  const vlen = b => { for (let i = 0; i < 8; i++) if (b & (0x80 >> i)) return i + 1; return 0; };
  let head = null, ch = 1; const pk = [];
  const CONT = new Set([0x18538067, 0x1654AE6B, 0xAE, 0x1F43B675, 0xA0, 0xE1]);
  let p = 0;
  while (p < buf.length) {
    const il = vlen(buf[p]); if (!il) break; let id = 0; for (let i = 0; i < il; i++) id = id * 256 + buf[p + i]; p += il;
    const sl = vlen(buf[p]); if (!sl) break; let sz = buf[p] & (0xFF >> sl), ones = sz === (0xFF >> sl);
    for (let i = 1; i < sl; i++) { sz = sz * 256 + buf[p + i]; if (buf[p + i] !== 0xFF) ones = false; } p += sl;
    if (CONT.has(id)) continue;                                   // step inside containers (also unknown-size ones)
    if (ones) break; const d = p, e = Math.min(buf.length, p + sz);
    if (id === 0x63A2) head = buf.slice(d, e);
    else if (id === 0x9F) { let v = 0; for (let i = d; i < e; i++) v = v * 256 + buf[i]; ch = v || 1; }
    else if (id === 0xA3 || id === 0xA1) { const tl = vlen(buf[d]); const fl = buf[d + tl + 2]; if (fl & 0x06) throw new Error('laced');
      pk.push(buf.slice(d + tl + 3, e)); }
    p = e;
  }
  if (!pk.length) throw new Error('no audio');
  if (!head || head.length < 19 || head.toString('latin1', 0, 8) !== 'OpusHead') {
    head = Buffer.alloc(19); head.write('OpusHead', 0, 'latin1'); head[8] = 1; head[9] = ch; head.writeUInt16LE(0, 10); head.writeUInt32LE(48000, 12); head.writeInt16LE(0, 16); head[18] = 0; }
  const vend = Buffer.from('Bigshow POS', 'latin1'), tags = Buffer.alloc(8 + 4 + vend.length + 4);
  tags.write('OpusTags', 0, 'latin1'); tags.writeUInt32LE(vend.length, 8); vend.copy(tags, 12); tags.writeUInt32LE(0, 12 + vend.length);
  const CRC = new Uint32Array(256); for (let i = 0; i < 256; i++) { let r = i << 24; for (let j = 0; j < 8; j++) r = (r & 0x80000000) ? ((r << 1) ^ 0x04C11DB7) : (r << 1); CRC[i] = r >>> 0; }
  const crc = b => { let c = 0; for (let i = 0; i < b.length; i++) c = ((c << 8) ^ CRC[((c >>> 24) ^ b[i]) & 0xFF]) >>> 0; return c; };
  const dur = q => { if (!q.length) return 0; const t = q[0], c = t >> 3;
    const fs = c < 12 ? [480, 960, 1920, 2880][c & 3] : c < 16 ? [480, 960][c & 1] : [120, 240, 480, 960][c & 3];
    const n = (t & 3) === 0 ? 1 : (t & 3) < 3 ? 2 : (q.length > 1 ? q[1] & 0x3F : 1); return fs * n; };
  const serial = (Math.random() * 0xFFFFFFFF) >>> 0, out = []; let seq = 0;
  const page = (data, gran, type) => { const segs = []; let l = data.length; while (l >= 255) { segs.push(255); l -= 255; } segs.push(l);
    const h = Buffer.alloc(27 + segs.length); h.write('OggS', 0, 'latin1'); h[4] = 0; h[5] = type;
    h.writeBigInt64LE(BigInt(gran), 6); h.writeUInt32LE(serial, 14); h.writeUInt32LE(seq++, 18); h.writeUInt32LE(0, 22); h[26] = segs.length; segs.forEach((s, i) => h[27 + i] = s);
    const pg = Buffer.concat([h, data]); pg.writeUInt32LE(crc(pg), 22); out.push(pg); };
  page(head, 0, 0x02); page(tags, 0, 0);
  let g = head.readUInt16LE(10);
  pk.forEach((q, i) => { g += dur(q); page(q, g, i === pk.length - 1 ? 0x04 : 0); });
  return Buffer.concat(out);
}
module.exports = webmToOgg;
