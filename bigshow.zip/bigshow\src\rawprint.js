/* 🔌 Print to a USB receipt printer WITHOUT any driver.
   Almost every receipt printer (Xprinter, Rongta, Gprinter, Epson TM, HPRT, ZJiang...) understands ESC/POS.
   Windows always gives a USB printer its built-in "USB Printing Support" port, even with no driver installed,
   so we find that port, draw the receipt as a picture and send it straight to the printer. */
const { execFile } = require('child_process');
const fs = require('fs');
const GUID = '{28d78fad-5a12-11d1-ae5b-0000f803a8c2}';   // GUID_DEVINTERFACE_USBPRINT

const reg = key => new Promise(r => execFile('reg', ['query', key, '/s'], { windowsHide:true, maxBuffer:8e6 }, (e, out) => r(e ? '' : String(out))));


/* second way (Windows SetupAPI through PowerShell): finds the printer port exactly like Windows does, and can also send the data */
const os = require('os'), path = require('path');
const PS = String.raw`param([string]$mode, [string]$dev, [string]$file)
Add-Type -TypeDefinition @"
using System; using System.Runtime.InteropServices; using System.Collections.Generic;
public static class UP {
 [StructLayout(LayoutKind.Sequential)] public struct DI { public int cbSize; public Guid g; public int Flags; public IntPtr Reserved; }
 [DllImport("setupapi.dll", SetLastError=true)] static extern IntPtr SetupDiGetClassDevs(ref Guid g, IntPtr e, IntPtr h, int f);
 [DllImport("setupapi.dll", SetLastError=true)] static extern bool SetupDiEnumDeviceInterfaces(IntPtr s, IntPtr d, ref Guid g, int i, ref DI di);
 [DllImport("setupapi.dll", SetLastError=true, CharSet=CharSet.Unicode)] static extern bool SetupDiGetDeviceInterfaceDetail(IntPtr s, ref DI di, IntPtr det, int size, out int req, IntPtr dev);
 [DllImport("setupapi.dll")] static extern bool SetupDiDestroyDeviceInfoList(IntPtr s);
 [DllImport("kernel32.dll", SetLastError=true, CharSet=CharSet.Unicode)] static extern IntPtr CreateFile(string n, uint a, uint sh, IntPtr sec, uint disp, uint fl, IntPtr t);
 [DllImport("kernel32.dll", SetLastError=true)] static extern bool WriteFile(IntPtr h, byte[] b, int n, out int w, IntPtr o);
 [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr h);
 public static string[] Find() { var r = new List<string>(); Guid g = new Guid("28d78fad-5a12-11d1-ae5b-0000f803a8c2");
  IntPtr s = SetupDiGetClassDevs(ref g, IntPtr.Zero, IntPtr.Zero, 0x12);
  for (int i = 0; i < 32; i++) { DI di = new DI(); di.cbSize = Marshal.SizeOf(di); if (!SetupDiEnumDeviceInterfaces(s, IntPtr.Zero, ref g, i, ref di)) break;
   int req; SetupDiGetDeviceInterfaceDetail(s, ref di, IntPtr.Zero, 0, out req, IntPtr.Zero); if (req <= 0) continue;
   IntPtr b = Marshal.AllocHGlobal(req); Marshal.WriteInt32(b, IntPtr.Size == 8 ? 8 : 6);
   if (SetupDiGetDeviceInterfaceDetail(s, ref di, b, req, out req, IntPtr.Zero)) r.Add(Marshal.PtrToStringUni(new IntPtr(b.ToInt64() + 4)));
   Marshal.FreeHGlobal(b); }
  SetupDiDestroyDeviceInfoList(s); return r.ToArray(); }
 public static string Send(string p, string f) { byte[] b = System.IO.File.ReadAllBytes(f);
  IntPtr h = CreateFile(p, 0x40000000, 3, IntPtr.Zero, 3, 0, IntPtr.Zero); if (h == new IntPtr(-1)) return "open-error " + Marshal.GetLastWin32Error();
  int w; bool ok = WriteFile(h, b, b.Length, out w, IntPtr.Zero); int e = Marshal.GetLastWin32Error(); CloseHandle(h); return ok ? "ok " + w : "write-error " + e; }
}
"@
if ($mode -eq 'find') { [UP]::Find() | ForEach-Object { 'DEV ' + $_ } } else { 'RES ' + [UP]::Send($dev, $file) }`;
function ps(args) { const f = path.join(os.tmpdir(), 'pos-usbprint.ps1'); fs.writeFileSync(f, PS);
  return new Promise(r => execFile('powershell', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', f, ...args], { windowsHide:true, timeout:30000 }, (e, out, err) => r({ out:String(out || ''), err:String(err || '') + (e ? ' ' + e.message : '') }))); }
const instOf = p => { const m = p.match(/^\\\\\?\\(usb)#(vid_[^#]+)#([^#]+)#/i); return m ? ('USB\\' + m[2] + '\\' + m[3]).toUpperCase() : ''; };
let last = '';   // details for log.txt

/* the USB printers that are plugged in now → [{ path, inst }] */
function parseClasses(out) {
  const found = [], L = out.split(/\r?\n/); let key = '', name = '', inst = {};
  L.forEach((l, i) => {
    if (/^HKEY_/.test(l)) { key = l.trim(); const m = key.match(/\\(##\?#[^\\]+)(\\|$)/); name = m ? m[1] : ''; return; }
    const v = l.trim().match(/^(\S+)\s+REG_\S+\s+(.*)$/); if (!v || !name) return;
    if (v[1] === 'DeviceInstance') inst[name] = v[2];
    if (v[1] === 'Linked' && /\\#\\Control$/i.test(key) && /0x1$/i.test(v[2])) found.push(name);
  });
  return [...new Set(found)].map(n => ({ path:'\\\\?\\' + n.slice(4), inst:inst[n] || '' }));
}
async function usbPrinters() {
  const out = await reg('HKLM\\SYSTEM\\CurrentControlSet\\Control\\DeviceClasses\\' + GUID);
  let list = parseClasses(out); last = 'reg ' + out.length + 'b/' + list.length;
  if (!list.length) { const r = await ps(['find']); list = r.out.split(/\r?\n/).filter(l => l.startsWith('DEV ')).map(l => ({ path:l.slice(4).trim(), inst:instOf(l.slice(4).trim()), api:1 }));
    last += ' | setupapi ' + list.length + (r.err.trim() ? ' err:' + r.err.trim().slice(0, 200) : ''); }
  for (const p of list) { const t = p.inst ? await reg('HKLM\\SYSTEM\\CurrentControlSet\\Enum\\' + p.inst) : '';
    p.desc = (t.match(/(FriendlyName|DeviceDesc|LocationInformation)\s+REG_SZ\s+(.*)/g) || []).join(' | ').replace(/\s+REG_SZ\s+/g, '='); }
  return list;
}

/* picture (BGRA) → ESC/POS raster commands */
function toEscPos(bgra, w, h) {
  const bw = Math.ceil(w / 8), dark = (x, y) => { const i = (y * w + x) * 4; return (bgra[i] * 0.114 + bgra[i + 1] * 0.587 + bgra[i + 2] * 0.299) < 160 && bgra[i + 3] > 60; };
  let last = h - 1; outer: for (; last > 0; last--) for (let x = 0; x < w; x++) if (dark(x, last)) break outer;   // cut the white space at the end
  const rows = last + 1, parts = [Buffer.from([0x1B, 0x40])];                                                  // ESC @  (reset)
  for (let y0 = 0; y0 < rows; y0 += 200) { const n = Math.min(200, rows - y0), d = Buffer.alloc(bw * n);
    for (let y = 0; y < n; y++) for (let x = 0; x < w; x++) if (dark(x, y0 + y)) d[y * bw + (x >> 3)] |= 0x80 >> (x & 7);
    parts.push(Buffer.from([0x1D, 0x76, 0x30, 0x00, bw & 255, bw >> 8, n & 255, n >> 8]), d); }                  // GS v 0  (raster picture)
  parts.push(Buffer.from([0x1B, 0x64, 0x05, 0x1D, 0x56, 0x42, 0x00]));                                          // feed 5 lines + cut
  return Buffer.concat(parts);
}

/* draw the receipt HTML at printer resolution (576 dots = 80 mm, 384 dots = 58 mm) */
async function render(html, dots) {
  const { BrowserWindow } = require('electron');
  const z = dots / 272, w = new BrowserWindow({ show:false, width:dots, height:400, useContentSize:true, webPreferences:{ offscreen:true, javascript:true } });
  try { await w.loadURL('data:text/html;charset=utf-8,' + encodeURIComponent(html));
    w.webContents.setZoomFactor(z); await new Promise(r => setTimeout(r, 250));
    const h = Math.min(12000, Math.ceil(await w.webContents.executeJavaScript('document.documentElement.scrollHeight') * z) + 10);
    w.setContentSize(dots, h); await new Promise(r => setTimeout(r, 400));
    const img = await w.webContents.capturePage({ x:0, y:0, width:dots, height:h }); const s = img.getSize();
    return { bgra:img.toBitmap(), w:s.width, h:s.height };
  } finally { setTimeout(() => { try { w.destroy(); } catch (x) {} }, 500); }
}

/* returns a short description of the printer used, or null when no USB receipt printer is plugged in */
async function print(html, cfg) {
  if (process.platform !== 'win32') return null;
  const list = await usbPrinters(); if (!list.length) return null;
  const p = list[0], mm = +(cfg && cfg.paper) || (/58/.test(p.desc + p.inst) ? 58 : 80), dots = mm === 58 ? 384 : 576;
  const pic = await render(html, dots); const data = toEscPos(pic.bgra, pic.w, pic.h);
  try { const fd = fs.openSync(p.path, 'r+'); try { fs.writeSync(fd, data); } finally { fs.closeSync(fd); } }
  catch (x) { const f = path.join(os.tmpdir(), 'pos-receipt.bin'); fs.writeFileSync(f, data); const r = await ps(['send', p.path, f]);
    if (!/RES ok/.test(r.out)) throw new Error('send failed: ' + x.message + ' / ' + (r.out + r.err).trim().slice(0, 200)); }
  return mm + 'mm ' + (p.desc || p.inst || p.path);
}
module.exports = { print, usbPrinters, parseClasses, toEscPos, info:() => last };
