/* 🔌 Print to a USB receipt printer WITHOUT any driver.
   Almost every receipt printer (Xprinter, Rongta, Gprinter, Epson TM, HPRT, ZJiang...) understands ESC/POS.
   Windows always gives a USB printer its built-in "USB Printing Support" port, even with no driver installed,
   so we find that port, draw the receipt as a picture and send it straight to the printer. */
const { execFile } = require('child_process');
const fs = require('fs');
const GUID = '{28d78fad-5a12-11d1-ae5b-0000f803a8c2}';   // GUID_DEVINTERFACE_USBPRINT

const reg = key => new Promise(r => execFile('reg', ['query', key, '/s'], { windowsHide:true, maxBuffer:8e6 }, (e, out) => r(e ? '' : String(out))));

/* the USB printers that are plugged in now → [{ path, inst }] */
function parseClasses(out) {
  const found = [], L = out.split(/\r?\n/); let key = '', name = '', inst = {};
  L.forEach((l, i) => {
    if (/^HKEY_/.test(l)) { key = l.trim(); const m = key.match(/\\(##\?#[^\\]+)(\\|$)/); name = m ? m[1] : ''; return; }
    const v = l.trim().match(/^(\S+)\s+REG_\S+\s+(.*)$/); if (!v || !name) return;
    if (v[1] === 'DeviceInstance') inst[name] = v[2];
    if (v[1] === 'Linked' && /\\#\\Control$/i.test(key) && /0x1$/i.test(v[2])) found.push(name);
  });
  return [...new Set(found)].map(n => ({ path:'\\\\?\\' + n.slice(4), inst:inst[n] || '' }));
}
async function usbPrinters() {
  const list = parseClasses(await reg('HKLM\\SYSTEM\\CurrentControlSet\\Control\\DeviceClasses\\' + GUID));
  for (const p of list) { const t = p.inst ? await reg('HKLM\\SYSTEM\\CurrentControlSet\\Enum\\' + p.inst) : '';
    p.desc = (t.match(/(FriendlyName|DeviceDesc|LocationInformation)\s+REG_SZ\s+(.*)/g) || []).join(' | ').replace(/\s+REG_SZ\s+/g, '='); }
  return list;
}

/* picture (BGRA) → ESC/POS raster commands */
function toEscPos(bgra, w, h) {
  const bw = Math.ceil(w / 8), dark = (x, y) => { const i = (y * w + x) * 4; return (bgra[i] * 0.114 + bgra[i + 1] * 0.587 + bgra[i + 2] * 0.299) < 160 && bgra[i + 3] > 60; };
  let last = h - 1; outer: for (; last > 0; last--) for (let x = 0; x < w; x++) if (dark(x, last)) break outer;   // cut the white space at the end
  const rows = last + 1, parts = [Buffer.from([0x1B, 0x40])];                                                  // ESC @  (reset)
  for (let y0 = 0; y0 < rows; y0 += 200) { const n = Math.min(200, rows - y0), d = Buffer.alloc(bw * n);
    for (let y = 0; y < n; y++) for (let x = 0; x < w; x++) if (dark(x, y0 + y)) d[y * bw + (x >> 3)] |= 0x80 >> (x & 7);
    parts.push(Buffer.from([0x1D, 0x76, 0x30, 0x00, bw & 255, bw >> 8, n & 255, n >> 8]), d); }                  // GS v 0  (raster picture)
  parts.push(Buffer.from([0x1B, 0x64, 0x05, 0x1D, 0x56, 0x42, 0x00]));                                          // feed 5 lines + cut
  return Buffer.concat(parts);
}

/* draw the receipt HTML at printer resolution (576 dots = 80 mm, 384 dots = 58 mm) */
async function render(html, dots) {
  const { BrowserWindow } = require('electron');
  const z = dots / 272, w = new BrowserWindow({ show:false, width:dots, height:400, useContentSize:true, webPreferences:{ offscreen:true, javascript:true } });
  try { await w.loadURL('data:text/html;charset=utf-8,' + encodeURIComponent(html));
    w.webContents.setZoomFactor(z); await new Promise(r => setTimeout(r, 250));
    const h = Math.min(12000, Math.ceil(await w.webContents.executeJavaScript('document.documentElement.scrollHeight') * z) + 10);
    w.setContentSize(dots, h); await new Promise(r => setTimeout(r, 400));
    const img = await w.webContents.capturePage({ x:0, y:0, width:dots, height:h }); const s = img.getSize();
    return { bgra:img.toBitmap(), w:s.width, h:s.height };
  } finally { setTimeout(() => { try { w.destroy(); } catch (x) {} }, 500); }
}

/* returns a short description of the printer used, or null when no USB receipt printer is plugged in */
async function print(html, cfg) {
  if (process.platform !== 'win32') return null;
  const list = await usbPrinters(); if (!list.length) return null;
  const p = list[0], mm = +(cfg && cfg.paper) || (/58/.test(p.desc + p.inst) ? 58 : 80), dots = mm === 58 ? 384 : 576;
  const pic = await render(html, dots); const data = toEscPos(pic.bgra, pic.w, pic.h);
  const fd = fs.openSync(p.path, 'r+'); try { fs.writeSync(fd, data); } finally { fs.closeSync(fd); }
  return mm + 'mm ' + (p.desc || p.inst || p.path);
}
module.exports = { print, usbPrinters, parseClasses, toEscPos };
